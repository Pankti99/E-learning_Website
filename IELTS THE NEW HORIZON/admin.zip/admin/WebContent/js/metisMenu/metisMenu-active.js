 (function ($) {
 "use strict";

	$('#main-menu').metisMenu();

})(jQuery);
