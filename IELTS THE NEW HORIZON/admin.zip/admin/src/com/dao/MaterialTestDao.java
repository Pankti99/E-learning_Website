package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.SpeakingTopic;
import com.bean.WrittingPessage;
import com.bean.WrittingPessageAnswer;
import com.mysql.jdbc.PreparedStatement;

public class MaterialTestDao {

	public List<WrittingPessage> listWrittingPessage() {

		List<WrittingPessage> list = new ArrayList<WrittingPessage>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblwritting_pessage";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					WrittingPessage writtingPessage = new WrittingPessage();
					writtingPessage.setDisplay_wirtting_pessage_id(i);
					writtingPessage.setWirtting_pessage_id(rs.getInt("writting_pessage_id"));
					writtingPessage.setWirtting_pessage_name(rs.getString("writting_pessage_name"));
					list.add(writtingPessage);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;

	}

	public WrittingPessageAnswer showWritingExam(int id) {

		WrittingPessageAnswer writtingPessageAnswer = new WrittingPessageAnswer();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblwritting_pessage_answer where writting_pessage_answer_id="+id;
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if (null != rs) {
				while (rs.next()) {
					writtingPessageAnswer.setWritting_pessage_answer(rs.getString("writting_pessage_answer"));
					writtingPessageAnswer.setWritting_pessage_answer_id(id);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return writtingPessageAnswer;

	}
	
	public List<WrittingPessageAnswer> listWrittingPessageAnswer() {

		List<WrittingPessageAnswer> list = new ArrayList<WrittingPessageAnswer>();
		ResultSet rs = null;
		try {
			String sql = "SELECT a.*,b.writting_pessage_name,c.user_detail_name FROM tblwritting_pessage_answer a, tblwritting_pessage b, tbluser_detail c where a.writting_pessage_id=b.writting_pessage_id and a.user_detail_id=c.user_detail_id and a.writting_pessage_band=0.0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					WrittingPessageAnswer writtingPessage = new WrittingPessageAnswer();
					writtingPessage.setDisplay_writting_pessage_answer_id(i);
					writtingPessage.setWritting_pessage_answer_id(rs.getInt("writting_pessage_answer_id"));
					writtingPessage.setUser_detail_name(rs.getString("user_detail_name"));
					writtingPessage.setWritting_pessage_name(rs.getString("writting_pessage_name"));
					
					list.add(writtingPessage);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;

	}

	public int saveWrittingPessage(String writtingPessageName) {
		
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblwritting_pessage(writting_pessage_name) VALUES (?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, writtingPessageName);
			retrunValue = ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return retrunValue;
	}

	public int saveSpeakingPessage(String writtingPessageName) {
		
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblspeaking_test(speaking_test_name,is_deleted) VALUES (?,?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, writtingPessageName);
			ps.setInt(2, 0);
			retrunValue = ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return retrunValue;
	}
	
	public void submitWrittenTestMarks(double score,int id) {
		try {
			String sql = "update tblwritting_pessage_answer set writting_pessage_band = ? where writting_pessage_answer_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setDouble(1, score);
			ps.setInt(2, id);
			ps.executeUpdate();

			
			
			String sql1 = "SELECT * FROM tblwritting_pessage_answer WHERE writting_pessage_answer_id = "+id;
			PreparedStatement ps1 = (PreparedStatement) connection.getConnection().prepareStatement(sql1);
			ResultSet rs1 = ps1.executeQuery();
			if (null != rs1) {
				while (rs1.next()) {

					String sql12 = "INSERT INTO tblreading_pessage_exam_result(paragraph_test_id, reading_pessage_score, "
							+ "user_detail_id, is_deleted, created_date, read_or_listening, practise_mock) VALUES (?,?,?,?,?,4,2)";
					PreparedStatement ps12 = (PreparedStatement) connection.getConnection().prepareStatement(sql12);

					ps12.setDouble(1, rs1.getInt("writting_pessage_id"));
					ps12.setDouble(2, score);
					ps12.setInt(3, rs1.getInt("user_detail_id"));
					ps12.setInt(4, 0);
					ps12.setTimestamp(5, rs1.getTimestamp("writting_pessage_date"));
					
					ps12.executeUpdate();

				
				}
			}

//			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	public List<SpeakingTopic> showSpeakingList() {

		List<SpeakingTopic> list = new ArrayList<SpeakingTopic>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblspeaking_test where is_deleted = 0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					SpeakingTopic speakingTopic = new SpeakingTopic();
					speakingTopic.setDisplay_speaking_topic_id(i);
					speakingTopic.setSpeaking_topic_id(rs.getInt("speaking_test_id"));
					speakingTopic.setSpeaking_topic_name(rs.getString("speaking_test_name"));
					list.add(speakingTopic);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;

	}

}
