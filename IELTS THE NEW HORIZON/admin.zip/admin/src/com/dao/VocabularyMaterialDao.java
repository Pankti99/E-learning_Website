package com.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.bean.UserDetail;
import com.bean.VocabularyCategory;
import com.bean.VocabularyMaterial;
import com.mysql.jdbc.PreparedStatement;

public class VocabularyMaterialDao {

	public List<VocabularyMaterial> listVocabulary(){
		
		List<VocabularyMaterial> list = new ArrayList<VocabularyMaterial>();
		
		ResultSet rs = null;
		try {
			String sql = "SELECT tv.*,tu.user_detail_name FROM tblvocabulary_material tv, tbluser_detail tu WHERE tv.user_detail_id=tu.user_detail_id and tv.is_deleted=0 and tu.is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i =1;
			if(null != rs) {
				while(rs.next()) {

					VocabularyMaterial vocabularyMaterial = new VocabularyMaterial();
					vocabularyMaterial.setUser_detail_id(rs.getInt("user_detail_id"));
					vocabularyMaterial.setVocabulary_material_description(rs.getString("vocabulary_material_description"));
					vocabularyMaterial.setVocabulary_material_example(rs.getString("vocabulary_material_example"));
					vocabularyMaterial.setDisplay_vocabulary_material_id(i);
					vocabularyMaterial.setVocabulary_material_id(rs.getInt("vocabulary_material_id"));
					vocabularyMaterial.setVocabulary_material_meaning(rs.getString("vocabulary_material_meaning"));
					vocabularyMaterial.setVocabulary_material_word(rs.getString("vocabulary_material_word"));
					vocabularyMaterial.setUser_detail_name(rs.getString("user_detail_name"));
					
					list.add(vocabularyMaterial);
					i++;
				}
			}
			

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	public List<VocabularyMaterial> listVocabulary1(int id){
		
		List<VocabularyMaterial> list = new ArrayList<VocabularyMaterial>();
		
		ResultSet rs = null;
		try {
			String sql = "SELECT tv.* FROM tblvocabulary_material tv WHERE tv.is_deleted=0 and vocabulary_material_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(null != rs) {
				while(rs.next()) {

					VocabularyMaterial vocabularyMaterial = new VocabularyMaterial();
					vocabularyMaterial.setVocabulary_material_description(rs.getString("vocabulary_material_description"));
					vocabularyMaterial.setVocabulary_material_example(rs.getString("vocabulary_material_example"));
					vocabularyMaterial.setVocabulary_material_id(rs.getInt("vocabulary_material_id"));
					vocabularyMaterial.setVocabulary_material_meaning(rs.getString("vocabulary_material_meaning"));
					vocabularyMaterial.setVocabulary_material_word(rs.getString("vocabulary_material_word"));
					
					list.add(vocabularyMaterial);
				}
			}
			

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public List<UserDetail> listUserDetail(){
		
		List<UserDetail> list = new ArrayList<UserDetail>();
		ResultSet rs = null;
		try {
			String sql = "SELECT tu.* FROM tbluser_detail tu WHERE tu.is_deleted=0 and user_type_id=3";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if(null != rs) {
				while(rs.next()) {
					UserDetail userDetail = new UserDetail();
					userDetail.setUser_detail_id(rs.getInt("user_detail_id"));
					userDetail.setUser_detail_name(rs.getString("user_detail_name"));
					
					list.add(userDetail);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
		
	}
	public List<VocabularyCategory> listVocabularyCategory() {

		List<VocabularyCategory> list = new ArrayList<VocabularyCategory>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblvocabulary_category WHERE is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					VocabularyCategory vocabularyCategory = new VocabularyCategory();
					vocabularyCategory.setDisplay_vocabulary_category_id(i);
					vocabularyCategory.setVocabulary_category_id(rs.getInt("vocabulary_category_id"));
					vocabularyCategory.setVocabulary_category_name(rs.getString("vocabulary_category_name"));

					list.add(vocabularyCategory);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;

	}

	public int saveVocabularyMaterial(VocabularyMaterial vocabularyMaterial) {
		int retrunValue = 0;

		try {
			if(vocabularyMaterial.getVocabulary_material_id() > 0) {
				String sql = "update tblvocabulary_material set vocabulary_material_word = ?, vocabulary_material_meaning = ?, vocabulary_material_description = ?,"
						+ " vocabulary_material_example = ? where vocabulary_material_id = ?";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

				ps.setString(1, vocabularyMaterial.getVocabulary_material_word());
				ps.setString(2, vocabularyMaterial.getVocabulary_material_meaning());
				ps.setString(3, vocabularyMaterial.getVocabulary_material_description());
				ps.setString(4, vocabularyMaterial.getVocabulary_material_example());
				ps.setInt(5, vocabularyMaterial.getVocabulary_material_id());
				retrunValue = ps.executeUpdate();
				
			} else {
				String sql = "INSERT INTO tblvocabulary_material(vocabulary_material_word, vocabulary_material_meaning, vocabulary_material_description, vocabulary_material_example, user_detail_id, is_deleted, is_created_date, is_updated_date,vocabulary_category_id) VALUES (?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

				ps.setString(1, vocabularyMaterial.getVocabulary_material_word());
				ps.setString(2, vocabularyMaterial.getVocabulary_material_meaning());
				ps.setString(3, vocabularyMaterial.getVocabulary_material_description());
				ps.setString(4, vocabularyMaterial.getVocabulary_material_example());
				
				ps.setInt(5, vocabularyMaterial.getUser_detail_id());
				ps.setInt(6, 0);
				ps.setTimestamp(7, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(8, new Timestamp(new java.util.Date().getTime()));
				ps.setInt(9, vocabularyMaterial.getVocabulary_category_id());
				retrunValue = ps.executeUpdate();
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return retrunValue;
	}
	
	public void vocabularyMaterialDelete(int id) {

		try {
			String sql = "update tblvocabulary_material set is_deleted = ?, is_updated_date = ? where vocabulary_material_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setInt(1, 1);
			ps.setTimestamp(2, new Timestamp(new java.util.Date().getTime()));
			ps.setInt(3, id);
			ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
}
