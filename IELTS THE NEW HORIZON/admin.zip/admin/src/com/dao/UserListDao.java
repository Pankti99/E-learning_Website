package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.UserDetail;
import com.mysql.jdbc.PreparedStatement;

public class UserListDao {
	public List<UserDetail> getUserDetail(int userType){
		
		List<UserDetail> list = new ArrayList<UserDetail>();
		ResultSet rs = null;
		try {
			String sql = "SELECT tu.* FROM tbluser_detail tu WHERE tu.is_deleted=0 and user_type_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, userType);
			rs = ps.executeQuery();
			int i = 1;
			if(null != rs) {
				while(rs.next()) {
					UserDetail userDetail = new UserDetail();
					userDetail.setUser_detail_id(rs.getInt("user_detail_id"));
					userDetail.setUser_detail_name(rs.getString("user_detail_name"));
					userDetail.setUser_detail_address(rs.getString("user_detail_address"));
					userDetail.setUser_detail_contact(rs.getString("user_detail_contact"));
					userDetail.setUser_detail_education(rs.getString("user_detail_education"));
					userDetail.setUser_detail_email(rs.getString("user_detail_email"));
					userDetail.setDisplay_user_detail_id(i);
					i++;
					
					list.add(userDetail);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
		
	}


}
