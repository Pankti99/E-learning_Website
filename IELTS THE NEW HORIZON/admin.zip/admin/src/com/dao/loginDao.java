package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.LoginInfo;
import com.bean.VocabularyCategory;
import com.mysql.jdbc.PreparedStatement;

public class loginDao {

	
	public LoginInfo ForgotPassword(String userName) {
		
		LoginInfo loginInfo = new LoginInfo();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tbluser_detail where user_detail_email= ? and is_deleted=0 and user_type_id < 4";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setString(1, userName);
			rs = ps.executeQuery();
			int i = 0;
			if (null != rs) {
				while (rs.next()) {
					i = 1;
					loginInfo.setUser_detail_id(rs.getInt("user_detail_id"));
					loginInfo.setContact(rs.getString("user_detail_contact"));
					loginInfo.setEmailId(rs.getString("user_detail_email"));
					loginInfo.setPassword(rs.getString("user_detail_password"));
					loginInfo.setUserName(rs.getString("user_detail_name"));
					loginInfo.setUserType(rs.getInt("user_type_id"));
				}
			}
			if(i==0) {
				loginInfo = null;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return loginInfo;
	}

	public LoginInfo login(String userName, String password) {
		LoginInfo loginInfo = new LoginInfo();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tbluser_detail where user_detail_email= ? and user_detail_password= ? and is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, password);
			rs = ps.executeQuery();
			int i = 0;
			if (null != rs) {
				while (rs.next()) {
					i = 1;
					loginInfo.setContact(rs.getString("user_detail_contact"));
					loginInfo.setEmailId(rs.getString("user_detail_email"));
					loginInfo.setPassword(rs.getString("user_detail_password"));
					loginInfo.setUserName(rs.getString("user_detail_name"));
					loginInfo.setUserType(rs.getInt("user_type_id"));
					loginInfo.setUser_detail_id(rs.getInt("user_detail_id"));
				}
			}
			if(i==0) {
				loginInfo = null;
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return loginInfo;

	}

	public int noOfStudent() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tbluser_detail WHERE is_deleted = 0 and user_type_id = 4";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfFaculty() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tbluser_detail WHERE is_deleted = 0 and user_type_id = 3";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfStaff() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tbluser_detail WHERE is_deleted = 0 and user_type_id = 2";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	
	
	
	public int noOfReadingTest() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(distinct paragraph_test_id) FROM tblreading_pessage_exam";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfWritingTest() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tblwritting_pessage";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfListeningTest() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(distinct listening_test_id) FROM tbllistening_pessage_exam where is_deleted= 0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfSpeakingTest() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(speaking_test_id) FROM tblspeaking_test";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	
	
	
	public int noOfReadingTestAttend() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tblreading_pessage_exam_result where read_or_listening = 1";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfWritingTestAttend() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(distinct writting_pessage_id,user_detail_id) FROM tblwritting_pessage_answer";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfListeningTestAttend() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tblreading_pessage_exam_result where read_or_listening = 2";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
	public int noOfSpeakingTestAttend() {
		int returnValue = 0;
		try {
			String sql = "SELECT count(*) FROM tblreading_pessage_exam_result where read_or_listening = 3";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				returnValue = Integer.parseInt(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return returnValue;
	}
}
