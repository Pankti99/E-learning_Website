package com.dao;

import java.sql.Timestamp;

import com.bean.UserDetail;
import com.mysql.jdbc.PreparedStatement;

public class AddUserDao {

	
	public int saveRegistration(UserDetail userDetail) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tbluser_detail(user_detail_name, user_detail_contact, user_detail_address, user_detail_email, user_detail_DOB, user_detail_education, user_detail_password, user_detail_payment, user_type_id, is_deleted, is_created_date, is_updated_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, userDetail.getUser_detail_name());
			ps.setString(2, userDetail.getUser_detail_contact());
			ps.setString(3, userDetail.getUser_detail_address());
			ps.setString(4, userDetail.getUser_detail_email());
			
			
			java.util.Date date1 = new java.util.Date();
			date1 = userDetail.getUser_detail_DOB();
			//System.out.println("date1 in DAO::"+date1);
			java.sql.Date bdate = new java.sql.Date(date1.getTime());

			
			ps.setDate(5, bdate);
			ps.setString(6, userDetail.getUser_detail_education());
			ps.setString(7, userDetail.getUser_detail_password());
			ps.setInt(8, userDetail.getUser_detail_payment());
			ps.setInt(9, userDetail.getUser_type_id());
			ps.setInt(10, 0);
			ps.setTimestamp(11, new Timestamp(new java.util.Date().getTime()));
			ps.setTimestamp(12, new Timestamp(new java.util.Date().getTime()));
			retrunValue = ps.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return retrunValue;
	}

	public void staffDelete(int id) {
		try {
			String sql = "update tbluser_detail set is_deleted = 1 where user_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setInt(1, id);
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
