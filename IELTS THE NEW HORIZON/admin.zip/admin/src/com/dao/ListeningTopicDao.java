package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.ListeningTopic;
import com.bean.ListeningTopicExam;
import com.bean.SpeakingBookSlot;
import com.mysql.jdbc.PreparedStatement;

public class ListeningTopicDao {

	public int saveListeningTopic(ListeningTopic listeningTopic) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tbllistening_test(listening_test_name, user_detail_id, file_name, is_deleted, created_date) VALUES (?,?,?,?,now())";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setString(1, listeningTopic.getListening_topic());
			ps.setInt(2, listeningTopic.getUser_detail_id());
			ps.setString(3, listeningTopic.getFile_name());
			ps.setInt(4, 0);
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

	public List<ListeningTopic> getListeningTopicList(int id){
		
		List<ListeningTopic> list = new ArrayList<ListeningTopic>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tbllistening_test WHERE is_deleted = 0 and user_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					ListeningTopic listeningTopic = new ListeningTopic();
					listeningTopic.setDisplay_listening_topic_id(i);
					listeningTopic.setFile_name(rs.getString("file_name"));
					listeningTopic.setListening_topic(rs.getString("listening_test_name"));
					listeningTopic.setListening_topic_id(rs.getInt("listening_test_id"));
					list.add(listeningTopic);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return list;
	}
	public List<ListeningTopicExam> getListeningTopicExamList(int id){

		System.out.println("Inside the Id : "+id);
		List<ListeningTopicExam> list = new ArrayList<ListeningTopicExam>();
		ResultSet rs = null;
		try {
			String sql = "SELECT t1.listening_test_name, t.* FROM tbllistening_pessage_exam t, tbllistening_test t1 WHERE t.listening_test_id=t1.listening_test_id and t1.user_detail_id = ? and t.is_deleted = 0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					ListeningTopicExam listeningTopicExam = new ListeningTopicExam();
					listeningTopicExam.setLstening_test_name(rs.getString("listening_test_name"));
					listeningTopicExam.setListening_test_que(rs.getString("listening_test_que"));
					listeningTopicExam.setListening_test_ans(rs.getString("listening_test_ans"));
					listeningTopicExam.setDisplay_listening_topic_exam_id(i);
					listeningTopicExam.setListening_topic_exam_id(rs.getInt("listening_exam_id"));
					list.add(listeningTopicExam);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return list;
	}	
	
	
	public void deleteListeningTopic(int id) {

		try {
			String sql = "update tbllistening_test set is_deleted = 1 WHERE listening_test_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	


	public void deleteListeningTopicExam(int id) {

		try {
			String sql = "update tbllistening_pessage_exam set is_deleted = 1 WHERE listening_exam_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	public int saveListeningTopicExam(ListeningTopicExam listeningTopic) {
		int retrunValue = 0;

		System.out.println("Come Inside");
		try {
			String sql = "INSERT INTO tbllistening_pessage_exam(listening_test_id, listening_test_que, listening_test_ans, is_deleted, created_date) VALUES (?,?,?,?,now())";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, listeningTopic.getListening_test_id());
			ps.setString(2, listeningTopic.getListening_test_que());
			ps.setString(3, listeningTopic.getListening_test_ans());
			ps.setInt(4, 0);
			retrunValue = ps.executeUpdate();

			System.out.println("return value "+retrunValue);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

	public List<SpeakingBookSlot> showSpeakingSlotList(int id) {

		List<SpeakingBookSlot> list = new ArrayList<SpeakingBookSlot>();
		ResultSet rs = null;
		try {
			String sql = "SELECT t.*,t1.speaking_test_name,DATE_FORMAT(t.speaking_date, '%d-%m-%Y') as display_speaking_date FROM tblspeaking_book_slot t,tblspeaking_test t1 WHERE t.speaking_test_id = t1.speaking_test_id and speaking_date <= now() and (speaking_date + interval 1 hour) >= now()";
			System.out.println("sql : "+sql);
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			System.out.println("RS : "+rs);
			if (null != rs) {
				while (rs.next()) {
					System.out.println("inside");
					SpeakingBookSlot speakingBookSlot = new SpeakingBookSlot();
					speakingBookSlot.setDisplay_id(i);
					System.out.println("1");
					speakingBookSlot.setDisplay_speaking_date(rs.getString("display_speaking_date"));
					speakingBookSlot.setSpeaking_test_name(rs.getString("speaking_test_name"));
					System.out.println("2");
					speakingBookSlot.setSpeaking_book_slot_id(rs.getInt("speaking_book_slot_id"));
					int fid = rs.getInt("faculty_id");
					System.out.println("3");
					String sql1 = "SELECT * from tbluser_detail where user_detail_id="+fid;
					System.out.println("sql1 : "+sql1);
					PreparedStatement ps1 = (PreparedStatement) connection.getConnection().prepareStatement(sql1);
					ResultSet rs1 = ps1.executeQuery();
					if (null != rs1) {
						while (rs1.next()) {
							System.out.println("RS :...............: "+rs1);
							speakingBookSlot.setFaculty_name(rs1.getString("user_detail_name"));
						}
					}
					
					
					list.add(speakingBookSlot);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}	

	public int saveSpeakingTest(int id,String band) {
		int retrunValue = 0;
		
		SpeakingBookSlot bookSlot = new SpeakingBookSlot();
		
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblspeaking_book_slot WHERE speaking_book_slot_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (null != rs) {
				while (rs.next()) {
					bookSlot.setUser_detail_id(rs.getInt("user_detail_id"));
					bookSlot.setSpeaking_test_id(rs.getInt("speaking_test_id"));
					bookSlot.setIs_mock(rs.getInt("is_mock"));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
		System.out.println("Come Inside");
		try {
			String sql = "INSERT INTO tblreading_pessage_exam_result(paragraph_test_id, reading_pessage_score, user_detail_id, is_deleted, created_date, read_or_listening, practise_mock) VALUES (?,?,?,0,now(),3,?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, bookSlot.getSpeaking_test_id());
			ps.setInt(2, Integer.parseInt(band));
			ps.setInt(3, bookSlot.getUser_detail_id());
			ps.setInt(4, bookSlot.getIs_mock());
			retrunValue = ps.executeUpdate();

			System.out.println("return value "+retrunValue);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

}
