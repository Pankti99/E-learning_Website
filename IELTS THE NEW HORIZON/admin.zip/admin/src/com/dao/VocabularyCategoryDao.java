package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.VocabularyCategory;
import com.mysql.jdbc.PreparedStatement;

public class VocabularyCategoryDao {

	public int saveVocabularyCategory(VocabularyCategory category) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblvocabulary_category(vocabulary_category_name, is_deleted) VALUES (?,?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, category.getVocabulary_category_name());
			ps.setInt(2, 0);
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;

	}

	public List<VocabularyCategory> listVocabularyCategory() {

		List<VocabularyCategory> list = new ArrayList<VocabularyCategory>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblvocabulary_category WHERE is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					VocabularyCategory vocabularyCategory = new VocabularyCategory();
					vocabularyCategory.setDisplay_vocabulary_category_id(i);
					vocabularyCategory.setVocabulary_category_id(rs.getInt("vocabulary_category_id"));
					vocabularyCategory.setVocabulary_category_name(rs.getString("vocabulary_category_name"));

					list.add(vocabularyCategory);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;

	}

	public int daleteVocabularyCategory(int id)
	{
		int returnValue = 0;
		try {
			String sql = "update tblvocabulary_category set is_deleted = 1 where vocabulary_category_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setInt(1, id);
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return returnValue;
	}
}
