package com.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.bean.ContactUsDetail;
import com.bean.MyProfile;
import com.bean.UserDetail;
import com.mysql.jdbc.PreparedStatement;

public class ContactUsDao {

	public List<ContactUsDetail> listContactUsDetail() {

		List<ContactUsDetail> list = new ArrayList<ContactUsDetail>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblcontact_us_detail";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if (null != rs) {
				while (rs.next()) {
					ContactUsDetail contactUsDetail = new ContactUsDetail();
					contactUsDetail.setContact_us_detail_id(rs.getInt("contact_us_detail_id"));
					contactUsDetail.setContact_us_detail_name(rs.getString("contact_us_detail_name"));
					contactUsDetail.setContact_us_detail_email(rs.getString("contact_us_detail_email"));
					contactUsDetail.setContact_us_detail_subject(rs.getString("contact_us_detail_subject"));
					contactUsDetail.setContact_us_detail_message(rs.getString("contact_us_detail_message"));

					String str = rs.getString("contact_us_detail_answer");
					System.out.println("String str = " + str);
					if (str.length() > 0) {
						contactUsDetail.setContact_us_detail_answer(str);
					} else {
						contactUsDetail.setContact_us_detail_answer("Answer Not Given");
					}

					list.add(contactUsDetail);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}

	public ContactUsDetail getContactDetailList(int contactUsDetailId) {

		ContactUsDetail contactUsDetail = new ContactUsDetail();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblcontact_us_detail where contact_us_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, contactUsDetailId);
			rs = ps.executeQuery();
			if (null != rs) {
				while (rs.next()) {
					contactUsDetail.setContact_us_detail_id(rs.getInt("contact_us_detail_id"));
					contactUsDetail.setContact_us_detail_email(rs.getString("contact_us_detail_email"));
					contactUsDetail.setContact_us_detail_message(rs.getString("contact_us_detail_message"));
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return contactUsDetail;
	}
	
	public int  saveContactUsDetailReplay(ContactUsDetail contactUsDetail) {
		int i=0;
		try {
			 i=contactUsDetail.getContact_us_detail_id();
			String sql = "update tblcontact_us_detail set is_deleted = 1, contact_us_detail_answer = ? where contact_us_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, contactUsDetail.getContact_us_detail_answer());
			ps.setInt(2, contactUsDetail.getContact_us_detail_id());
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	return i;

	}
	
	public MyProfile myprofile(int userDetailId) {

		MyProfile myProfile = new MyProfile();
		ResultSet rs = null;
		try {
			String sql = "SELECT *,DATE_FORMAT(user_detail_DOB, '%d-%m-%Y') as user_DOB FROM tbluser_detail WHERE user_detail_id="+userDetailId;
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if (null != rs) {
				while (rs.next()) {
					myProfile.setUser_detail_address(rs.getString("user_detail_address"));
					myProfile.setUser_detail_contact(rs.getString("user_detail_contact"));
					myProfile.setUser_detail_DOB(rs.getString("user_DOB"));
					myProfile.setUser_detail_education(rs.getString("user_detail_education"));
					myProfile.setUser_detail_email(rs.getString("user_detail_email"));
					myProfile.setUser_detail_name(rs.getString("user_detail_name"));
					
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return myProfile;
	}

	public void updateMyProfile(MyProfile myProfile) {
		
		try {
			String sql = "update tbluser_detail set user_detail_address = ?, user_detail_contact = ?, user_detail_education = ? where user_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setString(1, myProfile.getUser_detail_address());
			ps.setString(2, myProfile.getUser_detail_contact());
			ps.setString(3, myProfile.getUser_detail_education());
			ps.setInt(4, myProfile.getUser_detail_id());
			ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}
	
	public int deletecontact(int id)
	{
		int returnValue = 0;
		try {
			String sql = "delete from tblcontact_us_detail where contact_us_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

			ps.setInt(1, id);
			returnValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return returnValue;
	}
}
