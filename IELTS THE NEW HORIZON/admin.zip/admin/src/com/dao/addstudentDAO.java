package com.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;

import com.bean.addstudentbean;
import com.mysql.jdbc.PreparedStatement;

public class addstudentDAO {

	

	public int insertstd(addstudentbean bean) {
		int i = 1;
		try {
			if (bean.getStd_id() > 0) {
				String sql = "update stud set s_name=?,s_email=?,s_password=?,s_mob_num=?,birthdate=?,s_address=?,s_education=?,s_exam=?,s_band=?,is_created=?,is_updated=?,is_deleted=? where std_id=?";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
				ps.setString(1, bean.getStd_name());
				ps.setString(2, bean.getStd_email());
				ps.setString(3, bean.getStd_password());
				ps.setString(4,bean.getStd_mob_num());				

				java.util.Date date1 = new java.util.Date();
				date1 = bean.getBirth_date();
				//System.out.println("date1 in DAO::"+date1);
				java.sql.Date bdate = new java.sql.Date(date1.getTime());
				//System.out.println("bdate in DAO::"+bdate);
				ps.setDate(5, bdate);
				
				ps.setString(6, bean.getStd_address());
				ps.setString(7, bean.getStd_edu());
				System.out.println("student education::"+bean.getStd_edu());
				ps.setString(8, bean.getStd_exam());
			    ps.setFloat(9,bean.getStd_band());
			    
			    ps.setTimestamp(10, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(11, new Timestamp(new java.util.Date().getTime()));
				ps.setInt(12, 0);
				ps.setInt(13, bean.getStd_id());
				i = ps.executeUpdate();
				if(i>1)
				{
					System.out.println("In DAO Update");
				}
				return 2;
			} else {
				System.out.println("\ncome here DAO Insert ");
				String sql = "insert into stud(s_name,s_email,s_password,s_mob_num,birthdate,s_address,s_education,s_exam,s_band,regdate,is_created,is_updated,is_deleted) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
				ps.setString(1, bean.getStd_name());
				ps.setString(2, bean.getStd_email());
				ps.setString(3, bean.getStd_password());

				System.out.println("\ncome here DAO Insert "+bean.getStd_mob_num());
				ps.setString(4,bean.getStd_mob_num());				
				
				java.util.Date date1 = new java.util.Date();
				date1 = bean.getBirth_date();
				System.out.println("date1 in DAO::"+date1);
				java.sql.Date bdate = new java.sql.Date(date1.getTime());
				System.out.println("bdate in DAO::"+bdate);
				ps.setDate(5, bdate);
				

				ps.setString(6, bean.getStd_address());
				ps.setString(7, bean.getStd_edu());

				System.out.println("student education in DAO::"+bean.getStd_edu());
				ps.setString(8, bean.getStd_exam());
			    ps.setFloat(9,bean.getStd_band());
			    
			    ps.setTimestamp(10, new Timestamp(new java.util.Date().getTime()));
			    ps.setTimestamp(11, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(12, new Timestamp(new java.util.Date().getTime()));
				ps.setInt(13, 0);
				
				i = ps.executeUpdate();
				return i;
			}
		} catch (Exception e) {
			// TODO: handle exception

			System.out.println("\ncome here DAO Insert Exception");
			e.printStackTrace();
			return i;
		} finally {
			try {
				connection.getConnection().close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}

	public ResultSet getlist() {
		ResultSet rs = null;
		try {
			String sql = "select * from stud";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			return rs;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public void delete(int id) {
		try {
			String str = "delete from stud where std_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(str);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public ResultSet editlist(int id) {
		ResultSet rs = null;
		try {
			String str = "Select *  from stud where std_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(str);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			return rs;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

}
