package com.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.bean.VocabularyMaterial;
import com.bean.VocabularyTest;
import com.mysql.jdbc.PreparedStatement;

public class VocabularyTestDao {

	public List<VocabularyTest> listVocabularyTest() {
		List<VocabularyTest> vocabularyTestList = new ArrayList<VocabularyTest>();
		int i = 1;
		
		
		ResultSet rs = null;
		try {
			String sql = "SELECT t.*, t1.vocabulary_material_word FROM tblvocabulary_test t, tblvocabulary_material t1 WHERE t.vocabulary_material_id = t1.vocabulary_material_id AND t.is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if(null != rs) {
				while(rs.next()) {

					VocabularyTest vocabularyTest = new VocabularyTest();
					
					vocabularyTest.setVocabulary_test_id(rs.getInt("vocabulary_test_id"));
					vocabularyTest.setVocabulary_material_id(rs.getInt("vocabulary_material_id"));
					vocabularyTest.setOption1(rs.getString("option1"));
					vocabularyTest.setOption2(rs.getString("option2"));
					vocabularyTest.setOption3(rs.getString("option3"));
					vocabularyTest.setOption4(rs.getString("option4"));
					vocabularyTest.setCorrect_answer(rs.getInt("correct_answer"));
					vocabularyTest.setDisplay_vocabulary_test_id(i);
					vocabularyTest.setVocabulary_material_word(rs.getString("vocabulary_material_word"));
					
					vocabularyTestList.add(vocabularyTest);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return vocabularyTestList;
	}

	public List<VocabularyTest> listVocabularyTest1(int id) {
		List<VocabularyTest> vocabularyTestList = new ArrayList<VocabularyTest>();
		int i = 1;
		
		
		ResultSet rs = null;
		try {
			String sql = "SELECT t.* FROM tblvocabulary_test t WHERE t.vocabulary_test_id = ? AND t.is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(null != rs) {
				while(rs.next()) {

					VocabularyTest vocabularyTest = new VocabularyTest();
					
					vocabularyTest.setVocabulary_test_id(rs.getInt("vocabulary_test_id"));
					vocabularyTest.setVocabulary_material_id(rs.getInt("vocabulary_material_id"));
					vocabularyTest.setOption1(rs.getString("option1"));
					vocabularyTest.setOption2(rs.getString("option2"));
					vocabularyTest.setOption3(rs.getString("option3"));
					vocabularyTest.setOption4(rs.getString("option4"));
					vocabularyTest.setCorrect_answer(rs.getInt("correct_answer"));
					vocabularyTest.setDisplay_vocabulary_test_id(i);
					
					vocabularyTestList.add(vocabularyTest);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return vocabularyTestList;
	}

	
	public List<VocabularyMaterial> listVocabularyMaterial(){
		List<VocabularyMaterial> VocabularyMaterialList = new ArrayList<VocabularyMaterial>();
		ResultSet rs = null;
		try {
			String sql = "select * FROM tblvocabulary_material where is_deleted=0";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			if(null != rs) {
				while(rs.next()) {

					VocabularyMaterial vocabularyMaterial = new VocabularyMaterial();
					vocabularyMaterial.setVocabulary_material_id(rs.getInt("vocabulary_material_id"));
					vocabularyMaterial.setVocabulary_material_word(rs.getString("vocabulary_material_word"));
					VocabularyMaterialList.add(vocabularyMaterial);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return VocabularyMaterialList;
		
	}

	
	public int saveVocabularyTest(VocabularyTest vocabularyTest) {
		int retrunValue = 0;

		try {
			if(vocabularyTest.getVocabulary_test_id() > 0) {
				String sql = "update tblvocabulary_test set option1 = ?, option2 = ?, option3=?, option4=?, correct_answer=? where vocabulary_test_id = ?";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

				ps.setString(1, vocabularyTest.getOption1());
				ps.setString(2, vocabularyTest.getOption2());
				ps.setString(3, vocabularyTest.getOption3());
				ps.setString(4, vocabularyTest.getOption4());
				ps.setInt(5, vocabularyTest.getCorrect_answer());
				ps.setInt(6, vocabularyTest.getVocabulary_test_id());
				retrunValue = ps.executeUpdate();
				
			} else {
				String sql = "INSERT INTO tblvocabulary_test(vocabulary_material_id, option1, option2, option3, option4, correct_answer, is_deleted, is_created_date, is_updated_date) VALUES (?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);

				ps.setInt(1, vocabularyTest.getVocabulary_material_id());
				ps.setString(2, vocabularyTest.getOption1());
				ps.setString(3, vocabularyTest.getOption2());
				ps.setString(4, vocabularyTest.getOption3());
				ps.setString(5, vocabularyTest.getOption4());
				ps.setInt(6, vocabularyTest.getCorrect_answer());
				ps.setInt(7, 0);
				ps.setTimestamp(8, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(9, new Timestamp(new java.util.Date().getTime()));
				retrunValue = ps.executeUpdate();
				
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return retrunValue;

	}
	public void vocabularyTestDelete(int id) {
		try {
			String sql = "update tblvocabulary_test set is_deleted= 1 where vocabulary_test_id = "+id;
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.executeUpdate();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
