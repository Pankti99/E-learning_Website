package com.dao;
import java.sql.ResultSet;
import java.sql.Timestamp;
import com.bean.addfacultybean;
import com.mysql.jdbc.PreparedStatement;

public class addfacultyDAO
{
	public int insertfac(addfacultybean bean)
	{
		int i = 1;
		try 
		{
			if (bean.getF_id() > 0) 
			{
				System.out.println("In Update IF of DAO ");
				String sql = "update faculty set f_name=?,email=?,password=?,mob_num=?,birth_date=?,address=?,experience=?,age=?,is_created=?,is_updated=?,is_deleted=? where f_id=?";
				PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
				ps.setString(1, bean.getF_name());
				ps.setString(2, bean.getF_email());
				ps.setString(3, bean.getF_password());
				ps.setString(4, bean.getF_mob_num());
				
				java.util.Date date1 = new java.util.Date();
				date1 = bean.getBirth_date();
				//System.out.println("date1 in DAO::"+date1);
				java.sql.Date bdate = new java.sql.Date(date1.getTime());
				//System.out.println("bdate in DAO::"+bdate);
				ps.setDate(5, bdate);
				
				ps.setString(6, bean.getF_address());
				ps.setString(7, bean.getF_experience());
				ps.setInt(8, bean.getF_age());
				
				//ps.setTimestamp(9, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(9, new Timestamp(new java.util.Date().getTime()));
				ps.setTimestamp(10, new Timestamp(new java.util.Date().getTime()));
				ps.setInt(11, 0);
				ps.setInt(12, bean.getF_id());
				i = ps.executeUpdate();
				if(i>1)
				{
					System.out.println("In DAO Update");
				}
				return 2;
			} 
			else 
			{
			
			String sql = "insert into faculty(f_name,email,password,mob_num,birth_date,address,experience,age,regdate,is_created,is_updated,is_deleted) values (?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
	
			ps.setString(1, bean.getF_name());
			ps.setString(2, bean.getF_email());
			ps.setString(3, bean.getF_password());
			ps.setString(4, bean.getF_mob_num());
			
			java.util.Date date1 = new java.util.Date();
			date1 = bean.getBirth_date();
			System.out.println("date1 in DAO::"+date1);
			java.sql.Date bdate = new java.sql.Date(date1.getTime());
			System.out.println("bdate in DAO::"+bdate);
			ps.setDate(5, bdate);
			
			ps.setString(6, bean.getF_address());
			ps.setString(7, bean.getF_experience());
			ps.setInt(8, bean.getF_age());
			
			ps.setTimestamp(9, new Timestamp(new java.util.Date().getTime()));
			ps.setTimestamp(10, new Timestamp(new java.util.Date().getTime()));
			ps.setTimestamp(11, new Timestamp(new java.util.Date().getTime()));
			ps.setInt(12, 0);
			i = ps.executeUpdate();
			return i;
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return i;
		} finally {
			try {
				connection.getConnection().close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}
	public ResultSet getlist() {
		ResultSet rs = null;
		try {
			String sql = "select * from faculty";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			rs = ps.executeQuery();
			return rs;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

	public void delete(int id) {
		try {
			String str = "delete from faculty where f_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(str);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public ResultSet editlist(int id) {
		ResultSet rs = null;
		try {
			String str = "Select * from faculty where f_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(str);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			return rs;

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
	}

}