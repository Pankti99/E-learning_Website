package com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bean.ParagraphTest;
import com.bean.ReadingPessageExam;
import com.bean.ReadingPesssage;
import com.mysql.jdbc.PreparedStatement;

public class ReadingPessageDao {
	public List<ParagraphTest> listParagraphTest(int id) {

		List<ParagraphTest> list = new ArrayList<ParagraphTest>();
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM tblparagraph_test WHERE is_deleted=0 and user_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					ParagraphTest paragraphTest = new ParagraphTest();
					paragraphTest.setDisplay_paragraph_test_id(i);
					paragraphTest.setParagraph_test_id(rs.getInt("paragraph_test_id"));
					paragraphTest.setParagraph_test_name(rs.getString("paragraph_test_name"));

					list.add(paragraphTest);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	

	public List<ReadingPesssage> listReadingPessage(int id) {

		List<ReadingPesssage> list = new ArrayList<ReadingPesssage>();
		ResultSet rs = null;
		try {
			String sql = "SELECT t.*, t1.paragraph_test_name FROM tblreading_pessage t, tblparagraph_test t1 WHERE t.paragraph_test_id=t1.paragraph_test_id and t.is_deleted = 0 and t1.is_deleted = 0 and t1.user_detail_id=?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					ReadingPesssage readingPesssage = new ReadingPesssage();
					readingPesssage.setDisplay_reading_pessage_id(i);
					readingPesssage.setReading_pessage(rs.getString("reading_pessage"));
					readingPesssage.setReading_pessage_id(rs.getInt("reading_pessage_id"));
					readingPesssage.setParagraph_test_name(rs.getString("paragraph_test_name"));
					
					list.add(readingPesssage);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public List<ReadingPessageExam> listReadingPessageExam(int id) {

		List<ReadingPessageExam> list = new ArrayList<ReadingPessageExam>();
		ResultSet rs = null;
		try {
			String sql = "SELECT t.*,t1.paragraph_test_name FROM tblreading_pessage_exam t, tblparagraph_test t1 WHERE t.paragraph_test_id = t1.paragraph_test_id and t.is_deleted = 0 and t1.is_deleted = 0 and t1.user_detail_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			int i = 1;
			if (null != rs) {
				while (rs.next()) {
					ReadingPessageExam readingPessageExam = new ReadingPessageExam();
					readingPessageExam.setDisplay_reading_pessage_exam_id(i);
					readingPessageExam.setParagraph_test_name(rs.getString("paragraph_test_name"));
					readingPessageExam.setParagraph_test_ans(rs.getString("paragraph_test_ans"));
					readingPessageExam.setParagraph_test_que(rs.getString("paragraph_test_que"));
					readingPessageExam.setReading_pessage_exam_id(rs.getInt("paragraph_exam_id"));
					list.add(readingPessageExam);
					i++;
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public int saveParagraphTest(ParagraphTest paragraphTest) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblparagraph_test(paragraph_test_name, user_detail_id, is_deleted, created_date) VALUES (?,?,?,now())";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setString(1, paragraphTest.getParagraph_test_name());
			ps.setInt(2, paragraphTest.getUser_detail_id());
			ps.setInt(3, paragraphTest.getIs_deleted());
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

	public int deleteParagraphTest(int id) {
		int retrunValue = 0;

		try {
			String sql = "update tblparagraph_test set is_deleted = 1 where paragraph_test_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

	
	public int saveReadingPessage(ReadingPesssage readingPesssage) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblreading_pessage(paragraph_test_id, reading_pessage, is_deleted, created_date) VALUES (?,?,?, now())";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, readingPesssage.getParagraph_test_id());
			ps.setString(2, readingPesssage.getReading_pessage());
			ps.setInt(3, readingPesssage.getIs_deleted());
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}
	
	public int deleteReadingPessage(int id) {
		int retrunValue = 0;

		try {
			String sql = "update tblreading_pessage set is_deleted = 1 where reading_pessage_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

	public int saveReadingPessageExam(ReadingPessageExam readingPessageExam) {
		int retrunValue = 0;

		try {
			String sql = "INSERT INTO tblreading_pessage_exam(paragraph_test_id, paragraph_test_que, paragraph_test_ans, is_deleted, created_date) VALUES (?,?,?,?,now())";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, readingPessageExam.getParagraph_test_id());
			ps.setString(2, readingPessageExam.getParagraph_test_que());
			ps.setString(3, readingPessageExam.getParagraph_test_ans());
			ps.setInt(4, readingPessageExam.getIs_deleted());
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}
	
	public int deleteReadingPessageExam(int id) {
		int retrunValue = 0;

		try {
			String sql = "update tblreading_pessage_exam set is_deleted = 1 where paragraph_exam_id = ?";
			PreparedStatement ps = (PreparedStatement) connection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			retrunValue = ps.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return retrunValue;
	}

}
