package com.bean;

public class MyProfile {

	int user_detail_id;
	String user_detail_name, user_detail_contact, user_detail_address, user_detail_email, user_detail_DOB,
			user_detail_education, user_detail_password;

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public String getUser_detail_name() {
		return user_detail_name;
	}

	public void setUser_detail_name(String user_detail_name) {
		this.user_detail_name = user_detail_name;
	}

	public String getUser_detail_contact() {
		return user_detail_contact;
	}

	public void setUser_detail_contact(String user_detail_contact) {
		this.user_detail_contact = user_detail_contact;
	}

	public String getUser_detail_address() {
		return user_detail_address;
	}

	public void setUser_detail_address(String user_detail_address) {
		this.user_detail_address = user_detail_address;
	}

	public String getUser_detail_email() {
		return user_detail_email;
	}

	public void setUser_detail_email(String user_detail_email) {
		this.user_detail_email = user_detail_email;
	}

	public String getUser_detail_DOB() {
		return user_detail_DOB;
	}

	public void setUser_detail_DOB(String user_detail_DOB) {
		this.user_detail_DOB = user_detail_DOB;
	}

	public String getUser_detail_education() {
		return user_detail_education;
	}

	public void setUser_detail_education(String user_detail_education) {
		this.user_detail_education = user_detail_education;
	}

	public String getUser_detail_password() {
		return user_detail_password;
	}

	public void setUser_detail_password(String user_detail_password) {
		this.user_detail_password = user_detail_password;
	}

}
