package com.bean;

public class SpeakingTopic {
	int speaking_topic_id, display_speaking_topic_id;
	String speaking_topic_name;

	public int getSpeaking_topic_id() {
		return speaking_topic_id;
	}

	public void setSpeaking_topic_id(int speaking_topic_id) {
		this.speaking_topic_id = speaking_topic_id;
	}

	public int getDisplay_speaking_topic_id() {
		return display_speaking_topic_id;
	}

	public void setDisplay_speaking_topic_id(int display_speaking_topic_id) {
		this.display_speaking_topic_id = display_speaking_topic_id;
	}

	public String getSpeaking_topic_name() {
		return speaking_topic_name;
	}

	public void setSpeaking_topic_name(String speaking_topic_name) {
		this.speaking_topic_name = speaking_topic_name;
	}

}
