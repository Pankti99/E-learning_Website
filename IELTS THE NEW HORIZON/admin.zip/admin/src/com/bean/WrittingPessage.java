package com.bean;

public class WrittingPessage {
	int wirtting_pessage_id, display_wirtting_pessage_id;
	String wirtting_pessage_name;

	
	public int getDisplay_wirtting_pessage_id() {
		return display_wirtting_pessage_id;
	}

	public void setDisplay_wirtting_pessage_id(int display_wirtting_pessage_id) {
		this.display_wirtting_pessage_id = display_wirtting_pessage_id;
	}

	public int getWirtting_pessage_id() {
		return wirtting_pessage_id;
	}

	public void setWirtting_pessage_id(int wirtting_pessage_id) {
		this.wirtting_pessage_id = wirtting_pessage_id;
	}

	public String getWirtting_pessage_name() {
		return wirtting_pessage_name;
	}

	public void setWirtting_pessage_name(String wirtting_pessage_name) {
		this.wirtting_pessage_name = wirtting_pessage_name;
	}

}
