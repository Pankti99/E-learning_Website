package com.bean;

public class VocabularyResult {
	int vocabulary_resuslt_id, vocabulary_test_id, correct_or_wrong, user_detail_id;

	public int getVocabulary_resuslt_id() {
		return vocabulary_resuslt_id;
	}

	public void setVocabulary_resuslt_id(int vocabulary_resuslt_id) {
		this.vocabulary_resuslt_id = vocabulary_resuslt_id;
	}

	public int getVocabulary_test_id() {
		return vocabulary_test_id;
	}

	public void setVocabulary_test_id(int vocabulary_test_id) {
		this.vocabulary_test_id = vocabulary_test_id;
	}

	public int getCorrect_or_wrong() {
		return correct_or_wrong;
	}

	public void setCorrect_or_wrong(int correct_or_wrong) {
		this.correct_or_wrong = correct_or_wrong;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

}
