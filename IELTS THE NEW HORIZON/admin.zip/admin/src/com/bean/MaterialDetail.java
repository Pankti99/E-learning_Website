package com.bean;

public class MaterialDetail {
	int material_details_id, material_type_id, user_detail_id;
	String material_name, material_description, material_file_name;

	public int getMaterial_details_id() {
		return material_details_id;
	}

	public void setMaterial_details_id(int material_details_id) {
		this.material_details_id = material_details_id;
	}

	public int getMaterial_type_id() {
		return material_type_id;
	}

	public void setMaterial_type_id(int material_type_id) {
		this.material_type_id = material_type_id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public String getMaterial_name() {
		return material_name;
	}

	public void setMaterial_name(String material_name) {
		this.material_name = material_name;
	}

	public String getMaterial_description() {
		return material_description;
	}

	public void setMaterial_description(String material_description) {
		this.material_description = material_description;
	}

	public String getMaterial_file_name() {
		return material_file_name;
	}

	public void setMaterial_file_name(String material_file_name) {
		this.material_file_name = material_file_name;
	}

}
