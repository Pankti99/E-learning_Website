package com.bean;

public class ListeningTopicExam {
	int display_listening_topic_exam_id, listening_topic_exam_id, listening_test_id, user_detail_id;
	String listening_test_que, listening_test_ans, lstening_test_name;

	
	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public int getDisplay_listening_topic_exam_id() {
		return display_listening_topic_exam_id;
	}

	public void setDisplay_listening_topic_exam_id(int display_listening_topic_exam_id) {
		this.display_listening_topic_exam_id = display_listening_topic_exam_id;
	}

	public int getListening_topic_exam_id() {
		return listening_topic_exam_id;
	}

	public void setListening_topic_exam_id(int listening_topic_exam_id) {
		this.listening_topic_exam_id = listening_topic_exam_id;
	}

	public int getListening_test_id() {
		return listening_test_id;
	}

	public void setListening_test_id(int listening_test_id) {
		this.listening_test_id = listening_test_id;
	}

	public String getListening_test_que() {
		return listening_test_que;
	}

	public void setListening_test_que(String listening_test_que) {
		this.listening_test_que = listening_test_que;
	}

	public String getListening_test_ans() {
		return listening_test_ans;
	}

	public void setListening_test_ans(String listening_test_ans) {
		this.listening_test_ans = listening_test_ans;
	}

	public String getLstening_test_name() {
		return lstening_test_name;
	}

	public void setLstening_test_name(String lstening_test_name) {
		this.lstening_test_name = lstening_test_name;
	}

}
