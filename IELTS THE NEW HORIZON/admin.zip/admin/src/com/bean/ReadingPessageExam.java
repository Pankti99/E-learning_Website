package com.bean;

public class ReadingPessageExam {
	int display_reading_pessage_exam_id, reading_pessage_exam_id, paragraph_test_id, is_deleted;
	String paragraph_test_que, paragraph_test_ans, paragraph_test_name;


	public String getParagraph_test_name() {
		return paragraph_test_name;
	}

	public void setParagraph_test_name(String paragraph_test_name) {
		this.paragraph_test_name = paragraph_test_name;
	}

	public int getDisplay_reading_pessage_exam_id() {
		return display_reading_pessage_exam_id;
	}

	public void setDisplay_reading_pessage_exam_id(int display_reading_pessage_exam_id) {
		this.display_reading_pessage_exam_id = display_reading_pessage_exam_id;
	}

	public int getReading_pessage_exam_id() {
		return reading_pessage_exam_id;
	}

	public void setReading_pessage_exam_id(int reading_pessage_exam_id) {
		this.reading_pessage_exam_id = reading_pessage_exam_id;
	}

	public int getParagraph_test_id() {
		return paragraph_test_id;
	}

	public void setParagraph_test_id(int paragraph_test_id) {
		this.paragraph_test_id = paragraph_test_id;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	public String getParagraph_test_que() {
		return paragraph_test_que;
	}

	public void setParagraph_test_que(String paragraph_test_que) {
		this.paragraph_test_que = paragraph_test_que;
	}

	public String getParagraph_test_ans() {
		return paragraph_test_ans;
	}

	public void setParagraph_test_ans(String paragraph_test_ans) {
		this.paragraph_test_ans = paragraph_test_ans;
	}

}
