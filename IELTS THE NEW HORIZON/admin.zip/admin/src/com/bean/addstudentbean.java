package com.bean;

import java.util.Date;

public class addstudentbean {
	int std_id;
	String std_name,std_email,std_password,std_edu,std_exam,std_mob_num,std_address;
	
	float std_band;
	Date birth_date,regdate;
	String birth_date_display,reg;
	
	
	public String getStd_address() {
		return std_address;
	}
	public void setStd_address(String std_address) {
		this.std_address = std_address;
	}
	public int getStd_id() {
		return std_id;
	}
	public void setStd_id(int std_id) {
		this.std_id = std_id;
	}
	public String getStd_name() {
		return std_name;
	}
	public String getStd_mob_num() {
		return std_mob_num;
	}
	public void setStd_mob_num(String std_mob_num) {
		this.std_mob_num = std_mob_num;
	}
	public Date getBirth_date() {
		return birth_date;
	}
	public void setBirth_date(Date birth_date) {
		this.birth_date = birth_date;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public String getBirth_date_display() {
		return birth_date_display;
	}
	public void setBirth_date_display(String birth_date_display) {
		this.birth_date_display = birth_date_display;
	}
	public String getReg() {
		return reg;
	}
	public void setReg(String reg) {
		this.reg = reg;
	}
	public void setStd_name(String std_name) {
		this.std_name = std_name;
	}
	public String getStd_email() {
		return std_email;
	}
	public void setStd_email(String std_email) {
		this.std_email = std_email;
	}
	public String getStd_password() {
		return std_password;
	}
	public void setStd_password(String std_password) {
		this.std_password = std_password;
	}
	
	public String getStd_edu() {
		return std_edu;
	}
	public void setStd_edu(String std_edu) {
		this.std_edu = std_edu;
	}
	public String getStd_exam() {
		return std_exam;
	}
	public void setStd_exam(String std_exam) {
		this.std_exam = std_exam;
	}
	public float getStd_band() {
		return std_band;
	}
	public void setStd_band(float std_band) {
		this.std_band = std_band;
	}
	
}
