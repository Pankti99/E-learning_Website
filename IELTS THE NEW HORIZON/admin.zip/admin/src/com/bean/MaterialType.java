package com.bean;

public class MaterialType {
	int material_type_id;
	String material_type_name;

	public int getMaterial_type_id() {
		return material_type_id;
	}

	public void setMaterial_type_id(int material_type_id) {
		this.material_type_id = material_type_id;
	}

	public String getMaterial_type_name() {
		return material_type_name;
	}

	public void setMaterial_type_name(String material_type_name) {
		this.material_type_name = material_type_name;
	}

}
