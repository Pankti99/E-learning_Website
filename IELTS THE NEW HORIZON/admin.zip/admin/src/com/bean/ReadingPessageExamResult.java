package com.bean;

public class ReadingPessageExamResult {
	int tblreading_pessage_exam_result_id, reading_pessage_id, user_detail_id, is_deleted;
	double reading_pessage_score;

	public int getTblreading_pessage_exam_result_id() {
		return tblreading_pessage_exam_result_id;
	}

	public void setTblreading_pessage_exam_result_id(int tblreading_pessage_exam_result_id) {
		this.tblreading_pessage_exam_result_id = tblreading_pessage_exam_result_id;
	}

	public int getReading_pessage_id() {
		return reading_pessage_id;
	}

	public void setReading_pessage_id(int reading_pessage_id) {
		this.reading_pessage_id = reading_pessage_id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	public double getReading_pessage_score() {
		return reading_pessage_score;
	}

	public void setReading_pessage_score(double reading_pessage_score) {
		this.reading_pessage_score = reading_pessage_score;
	}

}
