package com.bean;

public class ReadingPesssage {
	int display_reading_pessage_id, reading_pessage_id, paragraph_test_id, is_deleted;
	String reading_pessage, paragraph_test_name;

	public String getParagraph_test_name() {
		return paragraph_test_name;
	}

	public void setParagraph_test_name(String paragraph_test_name) {
		this.paragraph_test_name = paragraph_test_name;
	}

	public int getDisplay_reading_pessage_id() {
		return display_reading_pessage_id;
	}

	public void setDisplay_reading_pessage_id(int display_reading_pessage_id) {
		this.display_reading_pessage_id = display_reading_pessage_id;
	}

	public int getReading_pessage_id() {
		return reading_pessage_id;
	}

	public void setReading_pessage_id(int reading_pessage_id) {
		this.reading_pessage_id = reading_pessage_id;
	}

	public int getParagraph_test_id() {
		return paragraph_test_id;
	}

	public void setParagraph_test_id(int paragraph_test_id) {
		this.paragraph_test_id = paragraph_test_id;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	public String getReading_pessage() {
		return reading_pessage;
	}

	public void setReading_pessage(String reading_pessage) {
		this.reading_pessage = reading_pessage;
	}

}
