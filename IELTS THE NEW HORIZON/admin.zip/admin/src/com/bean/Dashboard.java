package com.bean;

public class Dashboard {
	int noOfStudent, noOfFaculty, noOfStaff;
	int noOfReadingTest, noOfWritingTest, noOfListeningTest, noOfSpeakingTest;
	int noOfReadingTestAttend, noOfWritingTestAttend, noOfListeningTestAttend, noOfSpeakingTestAttend;

	public int getNoOfStudent() {
		return noOfStudent;
	}

	public void setNoOfStudent(int noOfStudent) {
		this.noOfStudent = noOfStudent;
	}

	public int getNoOfFaculty() {
		return noOfFaculty;
	}

	public void setNoOfFaculty(int noOfFaculty) {
		this.noOfFaculty = noOfFaculty;
	}

	public int getNoOfStaff() {
		return noOfStaff;
	}

	public void setNoOfStaff(int noOfStaff) {
		this.noOfStaff = noOfStaff;
	}

	public int getNoOfReadingTest() {
		return noOfReadingTest;
	}

	public void setNoOfReadingTest(int noOfReadingTest) {
		this.noOfReadingTest = noOfReadingTest;
	}

	public int getNoOfWritingTest() {
		return noOfWritingTest;
	}

	public void setNoOfWritingTest(int noOfWritingTest) {
		this.noOfWritingTest = noOfWritingTest;
	}

	public int getNoOfListeningTest() {
		return noOfListeningTest;
	}

	public void setNoOfListeningTest(int noOfListeningTest) {
		this.noOfListeningTest = noOfListeningTest;
	}

	public int getNoOfSpeakingTest() {
		return noOfSpeakingTest;
	}

	public void setNoOfSpeakingTest(int noOfSpeakingTest) {
		this.noOfSpeakingTest = noOfSpeakingTest;
	}

	public int getNoOfReadingTestAttend() {
		return noOfReadingTestAttend;
	}

	public void setNoOfReadingTestAttend(int noOfReadingTestAttend) {
		this.noOfReadingTestAttend = noOfReadingTestAttend;
	}

	public int getNoOfWritingTestAttend() {
		return noOfWritingTestAttend;
	}

	public void setNoOfWritingTestAttend(int noOfWritingTestAttend) {
		this.noOfWritingTestAttend = noOfWritingTestAttend;
	}

	public int getNoOfListeningTestAttend() {
		return noOfListeningTestAttend;
	}

	public void setNoOfListeningTestAttend(int noOfListeningTestAttend) {
		this.noOfListeningTestAttend = noOfListeningTestAttend;
	}

	public int getNoOfSpeakingTestAttend() {
		return noOfSpeakingTestAttend;
	}

	public void setNoOfSpeakingTestAttend(int noOfSpeakingTestAttend) {
		this.noOfSpeakingTestAttend = noOfSpeakingTestAttend;
	}

}
