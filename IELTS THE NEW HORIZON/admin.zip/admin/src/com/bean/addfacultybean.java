package com.bean;

import java.util.Date;

public class addfacultybean {
	String f_password,f_name,f_email,f_address,f_experience,f_mob_num;
	int f_id,f_age;
	Date birth_date,regdate;
	String birth_date_display,reg;
	
		
	public String getF_password() {
		return f_password;
	}
	public void setF_password(String f_password) {
		this.f_password = f_password;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getF_email() {
		return f_email;
	}
	public void setF_email(String f_email) {
		this.f_email = f_email;
	}
	public String getF_address() {
		return f_address;
	}
	public void setF_address(String f_address) {
		this.f_address = f_address;
	}
	public String getF_experience() {
		return f_experience;
	}
	public void setF_experience(String f_experience) {
		this.f_experience = f_experience;
	}
	public String getF_mob_num() {
		return f_mob_num;
	}
	public void setF_mob_num(String f_mob_num) {
		this.f_mob_num = f_mob_num;
	}
	public int getF_age() {
		return f_age;
	}
	public void setF_age(int f_age) {
		this.f_age = f_age;
	}
	
	public String getBirth_date_display() 
	{
		return birth_date_display;
	}
	public void setBirth_date_display(String birth_date_display) 
	{
	
		this.birth_date_display = birth_date_display;
	}
	public String getReg() {
		return reg;
	}
	public void setReg(String reg) {
		this.reg = reg;
	}
	
	public Date getBirth_date() {
		System.out.println("BEAN get::"+birth_date);
		return birth_date;
	}
	public void setBirth_date(Date birth_date) {

		System.out.println("BEAN set::"+birth_date);
		this.birth_date = birth_date;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public int getF_id() {
		return f_id;
	}
	public void setF_id(int f_id) {
		this.f_id = f_id;
	}
}
