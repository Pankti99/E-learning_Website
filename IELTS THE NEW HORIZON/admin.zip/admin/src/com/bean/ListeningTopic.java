package com.bean;

public class ListeningTopic {

	String listening_topic, file_name;
	int listening_topic_id, user_detail_id, display_listening_topic_id;

	public String getListening_topic() {
		return listening_topic;
	}

	public void setListening_topic(String listening_topic) {
		this.listening_topic = listening_topic;
	}

	public String getFile_name() {
		return file_name;
	}

	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public int getListening_topic_id() {
		return listening_topic_id;
	}

	public void setListening_topic_id(int listening_topic_id) {
		this.listening_topic_id = listening_topic_id;
	}

	public int getDisplay_listening_topic_id() {
		return display_listening_topic_id;
	}

	public void setDisplay_listening_topic_id(int display_listening_topic_id) {
		this.display_listening_topic_id = display_listening_topic_id;
	}

}
