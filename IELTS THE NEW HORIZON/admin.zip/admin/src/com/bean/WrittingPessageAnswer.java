package com.bean;

/**
 * @author dimple
 *
 */
public class WrittingPessageAnswer {
	int display_writting_pessage_answer_id;
	int writting_pessage_answer_id, writting_pessage_id, user_detail_id;
	String writting_pessage_answer,user_detail_name,writting_pessage_name;
	double writting_pessage_band;

	
	public String getUser_detail_name() {
		return user_detail_name;
	}

	public void setUser_detail_name(String user_detail_name) {
		this.user_detail_name = user_detail_name;
	}

	public String getWritting_pessage_name() {
		return writting_pessage_name;
	}

	public void setWritting_pessage_name(String writting_pessage_name) {
		this.writting_pessage_name = writting_pessage_name;
	}

	public int getDisplay_writting_pessage_answer_id() {
		return display_writting_pessage_answer_id;
	}

	public void setDisplay_writting_pessage_answer_id(int display_writting_pessage_answer_id) {
		this.display_writting_pessage_answer_id = display_writting_pessage_answer_id;
	}

	public int getWritting_pessage_answer_id() {
		return writting_pessage_answer_id;
	}

	public void setWritting_pessage_answer_id(int writting_pessage_answer_id) {
		this.writting_pessage_answer_id = writting_pessage_answer_id;
	}

	public int getWritting_pessage_id() {
		return writting_pessage_id;
	}

	public void setWritting_pessage_id(int writting_pessage_id) {
		this.writting_pessage_id = writting_pessage_id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public String getWritting_pessage_answer() {
		return writting_pessage_answer;
	}

	public void setWritting_pessage_answer(String writting_pessage_answer) {
		this.writting_pessage_answer = writting_pessage_answer;
	}

	public double getWritting_pessage_band() {
		return writting_pessage_band;
	}

	public void setWritting_pessage_band(double writting_pessage_band) {
		this.writting_pessage_band = writting_pessage_band;
	}

}
