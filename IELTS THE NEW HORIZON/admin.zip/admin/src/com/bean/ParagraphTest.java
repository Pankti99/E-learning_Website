package com.bean;

public class ParagraphTest {
	int display_paragraph_test_id, paragraph_test_id, user_detail_id, is_deleted;
	String paragraph_test_name;

	
	public int getDisplay_paragraph_test_id() {
		return display_paragraph_test_id;
	}

	public void setDisplay_paragraph_test_id(int display_paragraph_test_id) {
		this.display_paragraph_test_id = display_paragraph_test_id;
	}

	public int getParagraph_test_id() {
		return paragraph_test_id;
	}

	public void setParagraph_test_id(int paragraph_test_id) {
		this.paragraph_test_id = paragraph_test_id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	public String getParagraph_test_name() {
		return paragraph_test_name;
	}

	public void setParagraph_test_name(String paragraph_test_name) {
		this.paragraph_test_name = paragraph_test_name;
	}

}
