package com.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class UploadFiles {
	public static String saveFiles(File file, String fileName){
		FileInputStream in = null;
        FileOutputStream out = null;
        
        File dir = new File (CommonUse.filePath);
        String targetPath =  dir.getPath() + File.separator + fileName;
        File destinationFile = new File ( targetPath);
        try {
            in = new FileInputStream( file );
            out = new FileOutputStream( destinationFile );
            int c;

            while ((c = in.read()) != -1) {
                out.write(c);
            }
    		return "Success";
        }catch(Exception e){
        	e.printStackTrace();
    		return "error";
        }finally {
            if (in != null) {
                try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
            if (out != null) {
                try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            }
        }

	}
}
