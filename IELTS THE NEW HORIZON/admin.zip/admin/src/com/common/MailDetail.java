package com.common;


public class MailDetail {
	public static String fromMail = "dimplejoshi1510@gmail.com", fromPassword = "chirag@1210";
	public static String bodyContent = "Hello,<br><br>You are Registrer successfully. <br><br> User Name :";
	public static String bodyContentPass = "<br><br>Password : ";
	public static String contactreply="Thank you so much for contacting!! Your Answer is Below::";
}