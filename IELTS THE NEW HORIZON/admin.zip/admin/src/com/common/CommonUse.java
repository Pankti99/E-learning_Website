package com.common;

public class CommonUse {
	
	public static String filePath = "D:\\project\\UserSideIelts\\WebContent\\assets\\listening";
}
