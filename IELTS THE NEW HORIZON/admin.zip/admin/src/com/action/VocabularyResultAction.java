package com.action;

public class VocabularyResultAction {

}
