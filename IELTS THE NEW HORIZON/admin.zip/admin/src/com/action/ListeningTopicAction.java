package com.action;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.bean.ListeningTopic;
import com.bean.ListeningTopicExam;
import com.bean.LoginInfo;
import com.bean.SpeakingBookSlot;
import com.common.UploadFiles;
import com.dao.ListeningTopicDao;

public class ListeningTopicAction{

	String listening_topic;
	private File Listenfile;
	private String fileContentType;
	private String ListenfileFileName;

	
	int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	ListeningTopicDao topicDao = new ListeningTopicDao();
	List<ListeningTopic> list = new ArrayList<ListeningTopic>();
	List<ListeningTopicExam> list1 = new ArrayList<ListeningTopicExam>();

	public List<ListeningTopicExam> getList1() {
		return list1;
	}

	public void setList1(List<ListeningTopicExam> list1) {
		this.list1 = list1;
	}

	public List<ListeningTopic> getList() {
		return list;
	}

	public void setList(List<ListeningTopic> list) {
		this.list = list;
	}


	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}


	public String getListening_topic() {
		return listening_topic;
	}

	public void setListening_topic(String listening_topic) {
		this.listening_topic = listening_topic;
	}


	public File getListenfile() {
		return Listenfile;
	}

	public void setListenfile(File listenfile) {
		Listenfile = listenfile;
	}

	public String getListenfileFileName() {
		return ListenfileFileName;
	}

	public void setListenfileFileName(String listenfileFileName) {
		ListenfileFileName = listenfileFileName;
	}

	String message;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String saveListeningTopic() {
		
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");

		ListeningTopic listeningTopic = new ListeningTopic();
		UploadFiles.saveFiles(Listenfile, ListenfileFileName);
		listeningTopic.setFile_name(ListenfileFileName);
		listeningTopic.setListening_topic(listening_topic);
		listeningTopic.setUser_detail_id(loginInfo.getUser_detail_id());
		
		topicDao.saveListeningTopic(listeningTopic);
		message = "Record Saved Successfully.";
		return "success";
	}
	
	public String listeningTopic() {

		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");

		list = topicDao.getListeningTopicList(loginInfo.getUser_detail_id());
		return "success";
	}

	public String deleteListeningTopic() {
	
		topicDao.deleteListeningTopic(id);
		message = "Record Deleted Successfully.";
		return "success";
	}
	
	
	
	int listening_topic_id;
	String listening_test_ans,listening_test_que;
	
	public int getListening_topic_id() {
		return listening_topic_id;
	}

	public void setListening_topic_id(int listening_topic_id) {
		this.listening_topic_id = listening_topic_id;
	}

	public String getListening_test_ans() {
		return listening_test_ans;
	}

	public void setListening_test_ans(String listening_test_ans) {
		this.listening_test_ans = listening_test_ans;
	}

	public String getListening_test_que() {
		return listening_test_que;
	}

	public void setListening_test_que(String listening_test_que) {
		this.listening_test_que = listening_test_que;
	}

	
	public String speakingTopicExam() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");
		list = topicDao.getListeningTopicList(loginInfo.getUser_detail_id());
		list1 = topicDao.getListeningTopicExamList(loginInfo.getUser_detail_id());
		System.out.println("list1  : "+list1);
		return "success";
	}
	
	public String saveListeningExam() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");
		System.out.println("1");
		ListeningTopicExam listeningTopicExam = new ListeningTopicExam();
		listeningTopicExam.setListening_test_ans(listening_test_ans);
		listeningTopicExam.setListening_test_que(listening_test_que);
		listeningTopicExam.setListening_test_id(listening_topic_id);
		listeningTopicExam.setUser_detail_id(loginInfo.getUser_detail_id());
		System.out.println("2");
		topicDao.saveListeningTopicExam(listeningTopicExam);
		
		return "success";
	}
	
	public String deleteListeningExam() {
		topicDao.deleteListeningTopicExam(id);
		return "success";
	}
	List<SpeakingBookSlot> bookSlots = new ArrayList<SpeakingBookSlot>();
	
	public List<SpeakingBookSlot> getBookSlots() {
		return bookSlots;
	}

	public void setBookSlots(List<SpeakingBookSlot> bookSlots) {
		this.bookSlots = bookSlots;
	}

	
	public String showSpeakingSlotList() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo info = (LoginInfo)session.getAttribute("loginInfo");
		bookSlots = topicDao.showSpeakingSlotList(info.getUser_detail_id());
		return "success";
	}

	String speaking_score;

	public String getSpeaking_score() {
		return speaking_score;
	}

	public void setSpeaking_score(String speaking_score) {
		this.speaking_score = speaking_score;
	}
	
	public String speakingScoreSubmit() {
		System.out.println("Id : "+id);
		System.out.println("speaking_score : "+speaking_score);
		
		topicDao.saveSpeakingTest(id, speaking_score);
		return "success";
	}
}
