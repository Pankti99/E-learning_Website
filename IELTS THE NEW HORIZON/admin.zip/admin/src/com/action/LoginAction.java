package com.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.bean.Dashboard;
import com.bean.LoginInfo;
import com.dao.loginDao;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String userName, password;

	int noOfStudent, noOfFaculty, noOfStaff, id;
	int noOfReadingTest, noOfWritingTest, noOfListeningTest, noOfSpeakingTest;
	int noOfReadingTestAttend, noOfWritingTestAttend, noOfListeningTestAttend, noOfSpeakingTestAttend;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	Dashboard dashboard = new Dashboard();

	public int getNoOfStudent() {
		return noOfStudent;
	}

	public void setNoOfStudent(int noOfStudent) {
		this.noOfStudent = noOfStudent;
	}

	public int getNoOfFaculty() {
		return noOfFaculty;
	}

	public void setNoOfFaculty(int noOfFaculty) {
		this.noOfFaculty = noOfFaculty;
	}

	public int getNoOfStaff() {
		return noOfStaff;
	}

	public void setNoOfStaff(int noOfStaff) {
		this.noOfStaff = noOfStaff;
	}

	public int getNoOfReadingTest() {
		return noOfReadingTest;
	}

	public void setNoOfReadingTest(int noOfReadingTest) {
		this.noOfReadingTest = noOfReadingTest;
	}

	public int getNoOfWritingTest() {
		return noOfWritingTest;
	}

	public void setNoOfWritingTest(int noOfWritingTest) {
		this.noOfWritingTest = noOfWritingTest;
	}

	public int getNoOfListeningTest() {
		return noOfListeningTest;
	}

	public void setNoOfListeningTest(int noOfListeningTest) {
		this.noOfListeningTest = noOfListeningTest;
	}

	public int getNoOfSpeakingTest() {
		return noOfSpeakingTest;
	}

	public void setNoOfSpeakingTest(int noOfSpeakingTest) {
		this.noOfSpeakingTest = noOfSpeakingTest;
	}

	public int getNoOfReadingTestAttend() {
		return noOfReadingTestAttend;
	}

	public void setNoOfReadingTestAttend(int noOfReadingTestAttend) {
		this.noOfReadingTestAttend = noOfReadingTestAttend;
	}

	public int getNoOfWritingTestAttend() {
		return noOfWritingTestAttend;
	}

	public void setNoOfWritingTestAttend(int noOfWritingTestAttend) {
		this.noOfWritingTestAttend = noOfWritingTestAttend;
	}

	public int getNoOfListeningTestAttend() {
		return noOfListeningTestAttend;
	}

	public void setNoOfListeningTestAttend(int noOfListeningTestAttend) {
		this.noOfListeningTestAttend = noOfListeningTestAttend;
	}

	public int getNoOfSpeakingTestAttend() {
		return noOfSpeakingTestAttend;
	}

	public void setNoOfSpeakingTestAttend(int noOfSpeakingTestAttend) {
		this.noOfSpeakingTestAttend = noOfSpeakingTestAttend;
	}

	loginDao loginDao = new loginDao();

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	String message = "";

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String Login() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);

		LoginInfo loginInfo = loginDao.login(userName, password);
		if (null != loginInfo) {
			dashboard.setNoOfStaff(loginDao.noOfStaff());
			dashboard.setNoOfFaculty(loginDao.noOfFaculty());
			dashboard.setNoOfStudent(loginDao.noOfStudent());

			dashboard.setNoOfReadingTest(loginDao.noOfReadingTest());
			dashboard.setNoOfWritingTest(loginDao.noOfWritingTest());
			dashboard.setNoOfListeningTest(loginDao.noOfListeningTest());
			dashboard.setNoOfSpeakingTest(loginDao.noOfSpeakingTest());

			dashboard.setNoOfReadingTestAttend(loginDao.noOfReadingTestAttend());
			dashboard.setNoOfWritingTestAttend(loginDao.noOfWritingTestAttend());
			dashboard.setNoOfListeningTestAttend(loginDao.noOfListeningTestAttend());
			dashboard.setNoOfSpeakingTestAttend(loginDao.noOfSpeakingTestAttend());

			loginInfo.setDashboard(dashboard);
			session.setAttribute("loginInfo", loginInfo);
			return "success";
		} else {
			message = "Enter Username And Password does not match.";
			return "Error";
		}
	}

	public String logout() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(false);

		session.setAttribute("loginInfo", null);
		return "success";
	}

	public String forgotPassword() {
		LoginInfo loginInfo = loginDao.ForgotPassword(userName);
		if (null != loginInfo) {

			String bodyContent = "User Name : " + userName + "\n";
			bodyContent += "Password : " + loginInfo.getPassword();
			// mailSend.send(MailDetail.fromMail, MailDetail.fromPassword, userName, "Forgot
			// Password", bodyContent);

			message = "* Password send to your E-mail. Please check your mailbox.";
		} else {
			message = "* Username does not exists.";
		}
		return "success";

	}

	public String showSpeakingResultList() {

		return "success";
	}

	public String dashboard() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);

		LoginInfo loginInfo = (LoginInfo)session.getAttribute("loginInfo");
		if (null != loginInfo) {
			dashboard.setNoOfStaff(loginDao.noOfStaff());
			dashboard.setNoOfFaculty(loginDao.noOfFaculty());
			dashboard.setNoOfStudent(loginDao.noOfStudent());

			dashboard.setNoOfReadingTest(loginDao.noOfReadingTest());
			dashboard.setNoOfWritingTest(loginDao.noOfWritingTest());
			dashboard.setNoOfListeningTest(loginDao.noOfListeningTest());
			dashboard.setNoOfSpeakingTest(loginDao.noOfSpeakingTest());

			dashboard.setNoOfReadingTestAttend(loginDao.noOfReadingTestAttend());
			dashboard.setNoOfWritingTestAttend(loginDao.noOfWritingTestAttend());
			dashboard.setNoOfListeningTestAttend(loginDao.noOfListeningTestAttend());
			dashboard.setNoOfSpeakingTestAttend(loginDao.noOfSpeakingTestAttend());

			loginInfo.setDashboard(dashboard);

		}
		return "success";
	}
}