package com.action;

import java.util.ArrayList;
import java.util.List;

import com.bean.UserDetail;
import com.dao.UserListDao;

public class UserListAction {

	UserListDao userListDao = new UserListDao();
	List<UserDetail> list = new ArrayList<UserDetail>();
	int id;
	
	public List<UserDetail> getList() {
		return list;
	}

	public void setList(List<UserDetail> list) {
		this.list = list;
	}

	public String staffList() {
		list = userListDao.getUserDetail(2);
		
		return "success";
	}
	
	public String facultyList() {
		list = userListDao.getUserDetail(3);
		
		return "success";
	}
	public String studentList() {
		list = userListDao.getUserDetail(4);
		
		return "success";
	}

}
