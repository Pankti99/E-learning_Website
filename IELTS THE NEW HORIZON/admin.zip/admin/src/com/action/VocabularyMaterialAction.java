package com.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.bean.LoginInfo;
import com.bean.UserDetail;
import com.bean.VocabularyCategory;
import com.bean.VocabularyMaterial;
import com.dao.VocabularyMaterialDao;

public class VocabularyMaterialAction {

	VocabularyMaterialDao vocabularyMaterialDao = new VocabularyMaterialDao();
	List<VocabularyMaterial> vocabularyMaterialsList = new ArrayList<VocabularyMaterial>();
	List<UserDetail> userDetailsList = new ArrayList<UserDetail>();
	List<VocabularyCategory> vocabularyCategory = new ArrayList<VocabularyCategory>();
	
	int vocabulary_material_id, user_detail_id, id, vocabulary_category_id;
	String vocabulary_material_word, vocabulary_material_meaning, vocabulary_material_description, vocabulary_material_example;
	

	public List<VocabularyCategory> getVocabularyCategory() {
		return vocabularyCategory;
	}

	public void setVocabularyCategory(List<VocabularyCategory> vocabularyCategory) {
		this.vocabularyCategory = vocabularyCategory;
	}

	public int getVocabulary_category_id() {
		return vocabulary_category_id;
	}

	public void setVocabulary_category_id(int vocabulary_category_id) {
		this.vocabulary_category_id = vocabulary_category_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getVocabulary_material_id() {
		return vocabulary_material_id;
	}

	public void setVocabulary_material_id(int vocabulary_material_id) {
		this.vocabulary_material_id = vocabulary_material_id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public String getVocabulary_material_word() {
		return vocabulary_material_word;
	}

	public void setVocabulary_material_word(String vocabulary_material_word) {
		this.vocabulary_material_word = vocabulary_material_word;
	}

	public String getVocabulary_material_meaning() {
		return vocabulary_material_meaning;
	}

	public void setVocabulary_material_meaning(String vocabulary_material_meaning) {
		this.vocabulary_material_meaning = vocabulary_material_meaning;
	}

	public String getVocabulary_material_description() {
		return vocabulary_material_description;
	}

	public void setVocabulary_material_description(String vocabulary_material_description) {
		this.vocabulary_material_description = vocabulary_material_description;
	}

	public String getVocabulary_material_example() {
		return vocabulary_material_example;
	}

	public void setVocabulary_material_example(String vocabulary_material_example) {
		this.vocabulary_material_example = vocabulary_material_example;
	}

	public List<UserDetail> getUserDetailsList() {
		return userDetailsList;
	}

	public void setUserDetailsList(List<UserDetail> userDetailsList) {
		this.userDetailsList = userDetailsList;
	}

	public List<VocabularyMaterial> getVocabularyMaterialsList() {
		return vocabularyMaterialsList;
	}

	public void setVocabularyMaterialsList(List<VocabularyMaterial> vocabularyMaterialsList) {
		this.vocabularyMaterialsList = vocabularyMaterialsList;
	}

	public String listVocabulary() {

		vocabularyMaterialsList = vocabularyMaterialDao.listVocabulary();
		vocabularyCategory = vocabularyMaterialDao.listVocabularyCategory();
		return "success";
	}

	public String addVocabulary() {
		userDetailsList = vocabularyMaterialDao.listUserDetail();	
		vocabularyCategory = vocabularyMaterialDao.listVocabularyCategory();
		
		return "success";
	}
	
	public String saveVocabularyMaterial() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);

		LoginInfo loginInfo = (LoginInfo)session.getAttribute("loginInfo");

		VocabularyMaterial vocabularyMaterial = new VocabularyMaterial();
		
		if(vocabulary_material_id > 0) {
			vocabularyMaterial.setVocabulary_material_id(vocabulary_material_id);
		}
		vocabularyMaterial.setVocabulary_category_id(1);
		vocabularyMaterial.setUser_detail_id(loginInfo.getUser_detail_id());
		vocabularyMaterial.setVocabulary_material_description(vocabulary_material_description);
		vocabularyMaterial.setVocabulary_material_example(vocabulary_material_example);
		vocabularyMaterial.setVocabulary_material_meaning(vocabulary_material_meaning);
		vocabularyMaterial.setVocabulary_material_word(vocabulary_material_word);
		vocabularyMaterialDao.saveVocabularyMaterial(vocabularyMaterial);
		
		return "success";
	}
	
	
	public String vocabularyMaterialDelete() {
		vocabularyMaterialDao.vocabularyMaterialDelete(id);
		
		return "success";
	}
	
	public String vocabularyMaterialEdit() {
		
		vocabularyMaterialsList = vocabularyMaterialDao.listVocabulary1(id);
		VocabularyMaterial v = vocabularyMaterialsList.get(0);
		vocabulary_material_description = v.getVocabulary_material_description();
		vocabulary_material_example = v.getVocabulary_material_example();
		vocabulary_material_id = v.getVocabulary_material_id();
		vocabulary_material_meaning = v.getVocabulary_material_meaning();
		vocabulary_material_word = v.getVocabulary_material_word();
		
		return "success";
	}
	
}
