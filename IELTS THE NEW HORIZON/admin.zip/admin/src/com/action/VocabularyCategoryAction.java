package com.action;

import java.util.ArrayList;
import java.util.List;

import com.bean.VocabularyCategory;
import com.dao.VocabularyCategoryDao;

public class VocabularyCategoryAction {
	int vocabulary_category_id, id;
	String vocabulary_category_name;

	VocabularyCategoryDao categoryDao = new VocabularyCategoryDao();
	
	List<VocabularyCategory> list = new ArrayList<VocabularyCategory>();
	
	public List<VocabularyCategory> getList() {
		return list;
	}

	public void setList(List<VocabularyCategory> list) {
		this.list = list;
	}

	public int getVocabulary_category_id() {
		return vocabulary_category_id;
	}

	public void setVocabulary_category_id(int vocabulary_category_id) {
		this.vocabulary_category_id = vocabulary_category_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVocabulary_category_name() {
		return vocabulary_category_name;
	}

	public void setVocabulary_category_name(String vocabulary_category_name) {
		this.vocabulary_category_name = vocabulary_category_name;
	}

	public String saveVocabularyCategory() {
		VocabularyCategory vocabularyCategory = new VocabularyCategory();
		if(vocabulary_category_id > 0) {
			vocabularyCategory.setVocabulary_category_id(vocabulary_category_id);
		}
		vocabularyCategory.setVocabulary_category_name(vocabulary_category_name);
		int i = categoryDao.saveVocabularyCategory(vocabularyCategory);
		
		
		return "success";
	}
	
	public String getVocabularyCategoryList() {
		
		list = categoryDao.listVocabularyCategory();
		
		return "success";
	}
	
	public String daleteVocabularyCategory()
	{
		
		int i = categoryDao.daleteVocabularyCategory(id);
		return "success";
	}
}
