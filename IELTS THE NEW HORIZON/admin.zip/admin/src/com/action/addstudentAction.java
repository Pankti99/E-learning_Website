package com.action;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bean.addstudentbean;

import com.common.ConvertDateTime;
import com.dao.addstudentDAO;

public class addstudentAction {
	int std_id;
	String s_name, s_email, s_password;
	String s_mob_num =new String();
	String s_edu, s_exam,s_address;
	float s_band;
	String birth_date, regdate;
	List<addstudentbean> eb = null;
	String msg;

	public String getS_address() {
		return s_address;
	}

	public void setS_address(String s_address) {
		this.s_address = s_address;
	}

	public int getStd_id() {
		return std_id;
	}

	public void setStd_id(int std_id) {
		this.std_id = std_id;
	}

	public String getS_name() {
		return s_name;
	}

	public void setS_name(String s_name) {
		this.s_name = s_name;
	}

	public String getS_email() {
		return s_email;
	}

	public void setS_email(String s_email) {
		this.s_email = s_email;
	}

	public String getS_password() {
		return s_password;
	}

	public void setS_password(String s_password) {
		this.s_password = s_password;
	}
	
	public String getS_edu() {
		return s_edu;
	}

	public void setS_edu(String s_edu) {
		this.s_edu = s_edu;
	}

	public String getS_exam() {
		return s_exam;
	}

	public void setS_exam(String s_exam) {
		this.s_exam = s_exam;
	}

	public float getS_band() {
		return s_band;
	}

	public void setS_band(float s_band) {
		this.s_band = s_band;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public List<addstudentbean> getEb() {
		return eb;
	}

	public void setEb(List<addstudentbean> eb) {
		this.eb = eb;
	}

	public String getS_mob_num() {
		return s_mob_num;
	}

	public void setS_mob_num(String s_mob_num) {
		this.s_mob_num = s_mob_num;
	}

	public String getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String insert() {
		System.out.println("Come Here Action Insert");
		addstudentbean bean = new addstudentbean();
		if (std_id > 0) {
			bean.setStd_id(std_id);
		}
		bean.setStd_name(s_name);
		bean.setStd_email(s_email);
		bean.setStd_password(s_password);
		bean.setStd_mob_num(s_mob_num);
		
		
		Date bday = ConvertDateTime.convertDate(birth_date);
		try {
			System.out.println("birthdate in try in action::"+getBirth_date());
			bean.setBirth_date(bday);
		} catch (Exception e) {
			
		}
		
		bean.setStd_address(s_address);
		bean.setStd_edu(s_edu);
		bean.setStd_exam(s_exam);
		bean.setStd_band(s_band);
		
		int i = new addstudentDAO().insertstd(bean);
		if (i > 0) {
			if (i == 2) {
				msg = "Update SuccessFully";

				System.out.println(msg);
			} else {
				msg = "Insert Successfulyy";
				

				System.out.println(msg);
			}
		} else {
			msg = "some Error";

			System.out.println("Action::"+msg);
		}

		s_name = ""; 
		s_email = ""; 
		s_password = "";
		s_mob_num = ""; 
		s_edu = "";
		s_exam = "";
		s_address = "";
		birth_date = ""; 
		regdate = "";

		
		getlist();
		return "REGISTER";
	}
	public String getlist() {
		try {
			System.out.println("In the Action List finction");
			
			ResultSet rs = new addstudentDAO().getlist();
			eb = new ArrayList<addstudentbean>();
			if (rs != null) {
				while (rs.next()) {
					addstudentbean e = new addstudentbean();
					e.setStd_id(rs.getInt("std_id"));
					e.setStd_name(rs.getString("s_name"));
					e.setStd_email(rs.getString("s_email"));
					e.setStd_password(rs.getString("s_password"));
					e.setStd_mob_num(rs.getString("s_mob_num"));
					
					e.setBirth_date_display(rs.getString("birthdate"));
					
					e.setStd_address(rs.getString("s_address"));
					e.setStd_edu(rs.getString("s_education"));

					System.out.println("student education in action::"+rs.getString("s_education"));
					e.setStd_exam(rs.getString("s_exam"));
					e.setStd_band(rs.getFloat("s_band"));
					e.setReg(rs.getString("regdate"));
					eb.add(e);

				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("In the List finction error");
			
			System.out.println(e);
		}
		return "eb";
	}

	public String delete() {
		new addstudentDAO().delete(std_id);
		return "delete";
	}

	public String edit() {
		ResultSet rs = new addstudentDAO().editlist(std_id);
		try {
			if (rs != null) {
				while (rs.next()) {
					s_name = rs.getString("s_name");
					s_email = rs.getString("s_email");
					s_password = rs.getString("s_password");
					s_mob_num=rs.getString("s_mob_num");
					birth_date=rs.getString("birthdate");
					s_address=rs.getString("s_address");
					s_exam = rs.getString("s_exam");
					s_edu = rs.getString("s_education");
					s_band = rs.getFloat("s_band");

				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		getlist();
		return "edit";
	}

	
	
}