package com.action;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.bean.addfacultybean;

import com.common.ConvertDateTime;
import com.dao.addfacultyDAO;
import com.opensymphony.xwork2.ActionSupport;

public class addfacultyAction extends ActionSupport {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String password, f_name, email, address, experience,mob_num;
	int  f_id, age;
	String birth_date, regdate;
	List<addfacultybean> eb = null;
	String msg;
	
	public void setMob_num(String mob_num)
	{
		this.mob_num = mob_num;
	}

	public String getMob_num() 
	{
		return mob_num;
	}

	public List<addfacultybean> getEb()
	{
		return eb;
	}

	public void setEb(List<addfacultybean> eb)
	{
		this.eb = eb;
	}

	public int getAge()
	{
		return age;
	}
	
	public void setAge(int age) 
	{
		this.age = age;
	}

	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address) 
	{
		this.address = address;
	}

	public String getExperience() 
	{
		return experience;
	}

	public void setExperience(String experience)
	{
		this.experience = experience;
	}

	public int getF_id() {
		return f_id;
	}

	public void setF_id(int f_id) {
		this.f_id = f_id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}



	public String getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(String birth_date) {
		this.birth_date = birth_date;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String insert() {
		System.out.println("Come Here Insert ");		
		System.out.println("birthdate in action:::"+getBirth_date());
		addfacultybean bean = new addfacultybean();
		if(f_id>0)
		{
			bean.setF_id(f_id);
		}
		bean.setF_name(f_name);
		bean.setF_email(email);
		bean.setF_password(password);
		bean.setF_mob_num(mob_num);
		Date bday = ConvertDateTime.convertDate(birth_date);
		try {
			System.out.println("birthdate in try in action::"+getBirth_date());
			bean.setBirth_date(bday);
		} catch (Exception e) {
			
		}
		bean.setF_address(address);
		bean.setF_experience(experience);
		bean.setF_age(age);
		
		int i = new addfacultyDAO().insertfac(bean);
		if (i > 0) {
			if (i == 2) {
				msg = "Update SuccessFully";
			System.out.println(msg);
			} 
			else {
				msg = "Insert Successfulyy";
				System.out.println(msg);
			}
		} else {
			msg = "some Error";
		}
		getlist();
		return "REGISTER";
	}
	public String getlist() {
		try {
			System.out.println("In the List finction");
			ResultSet rs = new addfacultyDAO().getlist();
			eb = new ArrayList<addfacultybean>();
			if (rs != null) {
				while (rs.next()) {
					addfacultybean e = new addfacultybean();
					e.setF_id(rs.getInt("f_id"));
					System.out.println("F_ID in getlist action::"+rs.getInt("f_id"));
					e.setF_name(rs.getString("f_name"));
					e.setF_email(rs.getString("email"));
					e.setF_password(rs.getString("password"));
					e.setF_mob_num(rs.getString("mob_num"));
					e.setBirth_date_display(rs.getString("birth_date"));
					e.setF_address(rs.getString("address"));
					e.setF_experience(rs.getString("experience"));
					e.setF_age(rs.getInt("age"));
					e.setReg(rs.getString("regdate"));
					eb.add(e);
				}
			}
		} catch (Exception e) {

			System.out.println("In the List finction error");
			e.printStackTrace();
			// TODO: handle exception
		}
		return "eb";
	}
	public String delete() {
		new addfacultyDAO().delete(f_id);
		System.out.println("Delete");
		return "delete";
		
	}

	public String edit() {
		ResultSet rs = new addfacultyDAO().editlist(f_id);
		try {
			if (rs != null) {
				while (rs.next()) {
					f_name=rs.getString("f_name");
					email = rs.getString("email");
					password = rs.getString("password");
					mob_num=rs.getString("mob_num");
					birth_date=rs.getString("birth_date");
					address=rs.getString("address");
					experience=rs.getString("experience");
					age=rs.getInt("age");
					//regdate=rs.getString("regdate");
				}
				System.out.println("In the Edit finction Action");
			}
		} catch (Exception e) {

			System.out.println("Edit Error Action");
			// TODO: handle exception
			e.printStackTrace();
		}
		getlist();
		System.out.println("Edit Complete Action");
		return "edit";
	}
}