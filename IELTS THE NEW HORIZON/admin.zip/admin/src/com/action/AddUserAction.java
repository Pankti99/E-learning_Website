package com.action;

import com.bean.UserDetail;
import com.common.ConvertDateTime;
import com.common.MailDetail;
import com.common.MailSend;
import com.dao.AddUserDao;

public class AddUserAction {

	int user_detail_id, user_detail_payment, id;
	String user_detail_name, user_detail_contact, user_detail_address, user_detail_email, user_detail_education,
			user_detail_DOB;

	AddUserDao addUserDao = new AddUserDao();
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public int getUser_detail_payment() {
		return user_detail_payment;
	}

	public void setUser_detail_payment(int user_detail_payment) {
		this.user_detail_payment = user_detail_payment;
	}

	public String getUser_detail_name() {
		return user_detail_name;
	}

	public void setUser_detail_name(String user_detail_name) {
		this.user_detail_name = user_detail_name;
	}

	public String getUser_detail_contact() {
		return user_detail_contact;
	}

	public void setUser_detail_contact(String user_detail_contact) {
		this.user_detail_contact = user_detail_contact;
	}

	public String getUser_detail_address() {
		return user_detail_address;
	}

	public void setUser_detail_address(String user_detail_address) {
		this.user_detail_address = user_detail_address;
	}

	public String getUser_detail_email() {
		return user_detail_email;
	}

	public void setUser_detail_email(String user_detail_email) {
		this.user_detail_email = user_detail_email;
	}

	public String getUser_detail_education() {
		return user_detail_education;
	}

	public void setUser_detail_education(String user_detail_education) {
		this.user_detail_education = user_detail_education;
	}

	public String getUser_detail_DOB() {
		return user_detail_DOB;
	}

	public void setUser_detail_DOB(String user_detail_DOB) {
		this.user_detail_DOB = user_detail_DOB;
	}

	public String addStaff() {

		return "success";
	}

	public String addFaculty() {
		System.out.println("Come Faculty");
		return "success";
	}

	public String addStudent() {
		System.out.println("Come Student");
		return "success";
	}

	String message;
	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	MailSend mailSend = new MailSend();

	public void clearUserData() {
		user_detail_id = 0;
		user_detail_payment = 0;
		user_detail_name = ""; 
		user_detail_contact = ""; 
		user_detail_address = ""; 
		user_detail_email = "";
		user_detail_education = "";
		user_detail_DOB = "";;
	}

	public String saveStaffRegistration() {
		UserDetail userDetail = new UserDetail();
		
		if(user_detail_id > 0) {
			userDetail.setUser_detail_id(user_detail_id);
		}
		
		String password = user_detail_name + "@12345";
		userDetail.setUser_detail_email(user_detail_email);
		userDetail.setUser_detail_education(user_detail_education);
		userDetail.setUser_detail_contact(user_detail_contact);
		userDetail.setUser_detail_address(user_detail_address);
		userDetail.setUser_detail_name(user_detail_name);
		userDetail.setUser_detail_payment(user_detail_payment);
		userDetail.setUser_detail_password(password);
		userDetail.setUser_type_id(2);
		userDetail.setUser_detail_DOB(ConvertDateTime.convertDate(user_detail_DOB));
		
		
		int i = addUserDao.saveRegistration(userDetail);
		if(i > 0) {
			message = "Staff Register Successfully.";
			System.out.println("user_detail_email : "+user_detail_email);
		String bodyContent = MailDetail.bodyContent + " " +user_detail_email + MailDetail.bodyContentPass + " " + password ;
			mailSend.send(MailDetail.fromMail, MailDetail.fromPassword, user_detail_email, "Staff Registration Credential", bodyContent);
		} else {
			message = "Error Occur.";
		}
		clearUserData();
		return "success";
	}
	
	public String saveFacultyRegistration() {
		UserDetail userDetail = new UserDetail();
		
		if(user_detail_id > 0) {
			userDetail.setUser_detail_id(user_detail_id);
		}
		
		String password = user_detail_name + "@12345";
		userDetail.setUser_detail_email(user_detail_email);
		userDetail.setUser_detail_education(user_detail_education);
		userDetail.setUser_detail_contact(user_detail_contact);
		userDetail.setUser_detail_address(user_detail_address);
		userDetail.setUser_detail_name(user_detail_name);
		userDetail.setUser_detail_payment(user_detail_payment);
		userDetail.setUser_detail_password(password);
		userDetail.setUser_type_id(3);
		userDetail.setUser_detail_DOB(ConvertDateTime.convertDate(user_detail_DOB));
		
		
		int i = addUserDao.saveRegistration(userDetail);
		if(i > 0) {
			message = "Faculty Register Successfully.";
			
			String bodyContent = MailDetail.bodyContent + " " +user_detail_email + MailDetail.bodyContentPass + " " + password ;
			mailSend.send(MailDetail.fromMail, MailDetail.fromPassword, user_detail_email, "Faculty Registration Credential", bodyContent);
		} else {
			message = "Error Occur.";
		}
		clearUserData();
		return "success";
	}
	
	public String saveStudentRegistration() {
		UserDetail userDetail = new UserDetail();
		
		if(user_detail_id > 0) {
			userDetail.setUser_detail_id(user_detail_id);
		}
		
		String password = user_detail_name + "@12345";
		userDetail.setUser_detail_email(user_detail_email);
		userDetail.setUser_detail_education(user_detail_education);
		userDetail.setUser_detail_contact(user_detail_contact);
		userDetail.setUser_detail_address(user_detail_address);
		userDetail.setUser_detail_name(user_detail_name);
		userDetail.setUser_detail_payment(user_detail_payment);
		userDetail.setUser_detail_password(password);
		userDetail.setUser_type_id(4);
		userDetail.setUser_detail_DOB(ConvertDateTime.convertDate(user_detail_DOB));
		
		
		int i = addUserDao.saveRegistration(userDetail);
		if(i > 0) {
			message = "Student Register Successfully.";
			
			String bodyContent = MailDetail.bodyContent + " " +user_detail_email + MailDetail.bodyContentPass + " " + password ;
			mailSend.send(MailDetail.fromMail, MailDetail.fromPassword, user_detail_email, "Student Registration Credential", bodyContent);
		} else {
			message = "Error Occur.";
		}
		clearUserData();
		return "success";
	}
	
	public String staffDelete() {
		addUserDao.staffDelete(id);
		return "success";
	}
}
