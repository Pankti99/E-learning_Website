package com.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.bean.ContactUsDetail;
import com.bean.LoginInfo;
import com.bean.MyProfile;
import com.common.MailDetail;
import com.common.MailSend;
import com.dao.ContactUsDao;

public class ContactUsAction {

	int contact_us_detail_id;
	String contact_us_detail_message, contact_us_detail_answer, contact_us_detail_email;

	
	int user_detail_id;
	String user_detail_name, user_detail_contact, user_detail_address, user_detail_email, user_detail_DOB, user_detail_education, user_detail_password;
	
	public String getUser_detail_password() {
		return user_detail_password;
	}

	public void setUser_detail_password(String user_detail_password) {
		this.user_detail_password = user_detail_password;
	}

	public int getUser_detail_id() {
		return user_detail_id;
	}

	public void setUser_detail_id(int user_detail_id) {
		this.user_detail_id = user_detail_id;
	}

	public String getUser_detail_name() {
		return user_detail_name;
	}

	public void setUser_detail_name(String user_detail_name) {
		this.user_detail_name = user_detail_name;
	}

	public String getUser_detail_contact() {
		return user_detail_contact;
	}

	public void setUser_detail_contact(String user_detail_contact) {
		this.user_detail_contact = user_detail_contact;
	}

	public String getUser_detail_address() {
		return user_detail_address;
	}

	public void setUser_detail_address(String user_detail_address) {
		this.user_detail_address = user_detail_address;
	}

	public String getUser_detail_email() {
		return user_detail_email;
	}

	public void setUser_detail_email(String user_detail_email) {
		this.user_detail_email = user_detail_email;
	}

	public String getUser_detail_DOB() {
		return user_detail_DOB;
	}

	public void setUser_detail_DOB(String user_detail_DOB) {
		this.user_detail_DOB = user_detail_DOB;
	}

	public String getUser_detail_education() {
		return user_detail_education;
	}

	public void setUser_detail_education(String user_detail_education) {
		this.user_detail_education = user_detail_education;
	}

	public String getContact_us_detail_email() {
		return contact_us_detail_email;
	}

	public void setContact_us_detail_email(String contact_us_detail_email) {
		this.contact_us_detail_email = contact_us_detail_email;
	}

	public int getContact_us_detail_id() {
		return contact_us_detail_id;
	}

	public void setContact_us_detail_id(int contact_us_detail_id) {
		this.contact_us_detail_id = contact_us_detail_id;
	}

	public String getContact_us_detail_message() {
		return contact_us_detail_message;
	}

	public void setContact_us_detail_message(String contact_us_detail_message) {
		this.contact_us_detail_message = contact_us_detail_message;
	}

	public String getContact_us_detail_answer() {
		return contact_us_detail_answer;
	}

	public void setContact_us_detail_answer(String contact_us_detail_answer) {
		this.contact_us_detail_answer = contact_us_detail_answer;
	}

	ContactUsDao contactUsDao = new ContactUsDao();
	List<ContactUsDetail> list = new ArrayList<ContactUsDetail>();

	public List<ContactUsDetail> getList() {
		return list;
	}

	public void setList(List<ContactUsDetail> list) {
		this.list = list;
	}

	public String contactDetailList() {
		list = contactUsDao.listContactUsDetail();
		return "success";
	}
	int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContactDetailList() {
		ContactUsDetail contactUsDetail = contactUsDao.getContactDetailList(id);

		contact_us_detail_id = contactUsDetail.getContact_us_detail_id();
		contact_us_detail_message = contactUsDetail.getContact_us_detail_message();
		contact_us_detail_email = contactUsDetail.getContact_us_detail_email();
		return "success";
	}
	MailSend mailSend = new MailSend();
	public String saveContactUsDetailReplay() {
		ContactUsDetail contactUsDetail = new ContactUsDetail();
		contactUsDetail.setContact_us_detail_answer(contact_us_detail_answer);
		contactUsDetail.setContact_us_detail_email(contact_us_detail_email);
		contactUsDetail.setContact_us_detail_id(contact_us_detail_id);
		contactUsDao.saveContactUsDetailReplay(contactUsDetail);
		int i=contactUsDao.saveContactUsDetailReplay(contactUsDetail);
		if(i>0)
		{					
			String bodyContent =contact_us_detail_message+"regarding your question "+ MailDetail.contactreply + "\n " + getContact_us_detail_answer() ;
			System.out.println("body content"+bodyContent );
			mailSend.send(MailDetail.fromMail, MailDetail.fromPassword, getContact_us_detail_email(), "Contact us Information", bodyContent);
		}
		else 
		{
				message = "Error Occur.";
		}

		return "success";
	}
	public String deletecontact()
	{
		
		int i = contactUsDao.deletecontact(id);
		return "success";
	}
	
	public String myprofile() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");

		MyProfile myProfile = new MyProfile();
		myProfile = contactUsDao.myprofile(loginInfo.getUser_detail_id());
		user_detail_id = loginInfo.getUser_detail_id();
		user_detail_name = myProfile.getUser_detail_name();
		user_detail_address = myProfile.getUser_detail_address();
		user_detail_contact = myProfile.getUser_detail_contact();
		user_detail_DOB = myProfile.getUser_detail_DOB();
		user_detail_education = myProfile.getUser_detail_education();
		user_detail_email = myProfile.getUser_detail_email();
		return "success";
	}
	String message;
	
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String updateMyProfile() {
		HttpServletRequest httpServletRequest = ServletActionContext.getRequest();
		HttpSession session = httpServletRequest.getSession(true);
		LoginInfo loginInfo =  (LoginInfo)session.getAttribute("loginInfo");

		MyProfile myProfile = new MyProfile();
		myProfile.setUser_detail_address(user_detail_address);
		myProfile.setUser_detail_contact(user_detail_contact);
		myProfile.setUser_detail_education(user_detail_education);
		myProfile.setUser_detail_id(loginInfo.getUser_detail_id());
		contactUsDao.updateMyProfile(myProfile);
		message = "Profile Updated Successfully.";
		return "success";
	}
}
