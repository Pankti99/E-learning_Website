package com.action;

import java.util.ArrayList;
import java.util.List;

import com.bean.SpeakingTopic;
import com.bean.WrittingPessage;
import com.bean.WrittingPessageAnswer;
import com.dao.MaterialTestDao;

public class MaterialTestAction {
	int writting_pessage_id, id, writting_pessage_answer_id;
	String writting_pessage_name, writting_pessage_answer, writing_score;
	
	MaterialTestDao materialTestDao = new MaterialTestDao();

	List<WrittingPessage> list = new ArrayList<WrittingPessage>();
	List<WrittingPessageAnswer> list1 = new ArrayList<WrittingPessageAnswer>();
	WrittingPessageAnswer writtingPessageAnswer = new WrittingPessageAnswer();
	List<SpeakingTopic> speakingTopics = new ArrayList<SpeakingTopic>();

	
	public List<SpeakingTopic> getSpeakingTopics() {
		return speakingTopics;
	}

	public void setSpeakingTopics(List<SpeakingTopic> speakingTopics) {
		this.speakingTopics = speakingTopics;
	}

	public String getWriting_score() {
		return writing_score;
	}

	public void setWriting_score(String writing_score) {
		this.writing_score = writing_score;
	}

	public int getWritting_pessage_answer_id() {
		return writting_pessage_answer_id;
	}

	public void setWritting_pessage_answer_id(int writting_pessage_answer_id) {
		this.writting_pessage_answer_id = writting_pessage_answer_id;
	}

	public String getWritting_pessage_answer() {
		return writting_pessage_answer;
	}

	public void setWritting_pessage_answer(String writting_pessage_answer) {
		this.writting_pessage_answer = writting_pessage_answer;
	}

	public WrittingPessageAnswer getWrittingPessageAnswer() {
		return writtingPessageAnswer;
	}

	public void setWrittingPessageAnswer(WrittingPessageAnswer writtingPessageAnswer) {
		this.writtingPessageAnswer = writtingPessageAnswer;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<WrittingPessageAnswer> getList1() {
		return list1;
	}

	public void setList1(List<WrittingPessageAnswer> list1) {
		this.list1 = list1;
	}

	public int getWritting_pessage_id() {
		return writting_pessage_id;
	}

	public void setWritting_pessage_id(int writting_pessage_id) {
		this.writting_pessage_id = writting_pessage_id;
	}

	public String getWritting_pessage_name() {
		return writting_pessage_name;
	}

	public void setWritting_pessage_name(String writting_pessage_name) {
		this.writting_pessage_name = writting_pessage_name;
	}

	public List<WrittingPessage> getList() {
		return list;
	}

	public void setList(List<WrittingPessage> list) {
		this.list = list;
	}

	public String showWrittingList() {

		list = materialTestDao.listWrittingPessage();
		return "success";
	}

	public String saveWrittingPessage() {

		materialTestDao.saveWrittingPessage(writting_pessage_name);
		return "success";
	}
	
	public String saveSpeakingPessage() {

		System.out.println("writting_pessage_name : "+writting_pessage_name);
		materialTestDao.saveSpeakingPessage(writting_pessage_name);
		return "success";
	}
	
	

	public String checkWrittenPessage() {
		list1 = materialTestDao.listWrittingPessageAnswer();
		return "success";
	}

	public String showWritingExam() {
		writtingPessageAnswer = materialTestDao.showWritingExam(id);
		writting_pessage_answer = writtingPessageAnswer.getWritting_pessage_answer();
		writting_pessage_answer_id = writtingPessageAnswer.getWritting_pessage_answer_id();
		return "success";
	}
	
	public String submitWrittenTestMarks() {
		System.out.println("Band : "+writing_score);
		System.out.println("writting_pessage_answer_id : "+writting_pessage_answer_id);
		materialTestDao.submitWrittenTestMarks(Double.parseDouble(writing_score), writting_pessage_answer_id);
		return "success";
	}
	
	public String showSpeakingList() {
		
		speakingTopics = materialTestDao.showSpeakingList();
		
		return "success";
	}
}
