package darwinsys.chat;

public class UserState {
	public int firstViewed;
	public int lastViewed;
}
